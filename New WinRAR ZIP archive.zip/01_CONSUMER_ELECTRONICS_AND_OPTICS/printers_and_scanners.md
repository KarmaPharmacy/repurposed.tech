# 🖨️ Volume 1.1: Printers, Scanners & Copiers Salvage Guide
*Harvesting precision linear motion, optical scales, fusers, and high-torque hybrid steppers from office e-waste.*

---

## 1. Anatomy of Office E-Waste: What to Harvest

```
+-----------------------------------------------------------------------------------------------+
| Component             | Donor Device            | Primary Mechanical / Electrical Spec        |
| --------------------- | ----------------------- | ------------------------------------------- |
| Linear Ground Rods    | Inkjets, Lasers, Scanners| 6mm, 8mm, 10mm, 12mm hardened steel, h6 tol|
| Hybrid Stepper Motors | Laser Printers, Copiers | NEMA 17 & NEMA 23, 1.8° step, 4-wire bipolar|
| Linear Optical Strip  | Inkjet Printers         | 150–300 LPI transparent polyester strip + IC|
| Rotary Optical Disc   | Paper Feed Rollers      | High-PPR transparent disc + quadrature IC   |
| Fuser Assembly        | Laser Printers          | Halogen heat lamp (180°C–210°C) + silicone roll|
| Polygon Mirror Unit   | Laser Scanner Assemblies| 10,000–30,000 RPM BLDC with faceted mirror   |
| High-Voltage PSU      | Laser Printers          | 1,000V–6,000V DC (microamp corona charging) |
| Front-Surface Mirrors | Flatbed Scanners        | 98%+ optical reflectivity, zero ghosting    |
| Solenoids & Clutches  | Paper Feed Trays        | 12V / 24V DC electromagnetic clutches/stops |
+-----------------------------------------------------------------------------------------------+
```

---

## 2. In-Depth Subsystem Teardowns & Engineering Exploits

### A. The Linear Optical Encoder Strip: Free Machine Tool DRO
Modern inkjet printers do not use expensive stepper motors for their print carriages; they use cheap DC motors combined with an **optical linear encoder strip** to achieve sub-millimeter closed-loop positioning.

```
Encoder Read-Head Architecture:
  +----------------------------------------------------+
  | [IR LED Emitter]                                   |
  |         |                                          |
  |         v                                          |
  | =======[Transparent Strip with 150-300 LPI Grid]== |
  |         |                                          |
  |         v                                          |
  | [Dual Photodiode Receiver (Phase A & Phase B)]     |
  +----------------------------------------------------+
```

#### Pinout Identification:
The miniature reader PCB clipped to the print head typically has 4 to 6 solder pads:
- `VCC`: +3.3V or +5V DC
- `GND`: Ground
- `Channel A`: Digital square wave pulse
- `Channel B`: Digital square wave pulse (shifted 90° in phase for direction detection)

#### The Lathe / Milling Machine Digital Readout (DRO) Hack:
1. Unclip the clear encoder strip and unscrew the optical reader PCB from the carriage.
2. Fasten the optical reader to your lathe's cross-slide carriage and stretch the encoder strip along the lathe bed inside a protective 3D-printed or aluminum channel to shield it from metal shavings.
3. Wire Channel A and Channel B to Arduino/ESP32 pins `D2` and `D3` (Hardware Interrupts).
4. Run the firmware below: Each transition corresponds to **1/300th or 1/600th of an inch (approx. 40 to 80 microns)**, providing instant sub-millimeter digital measurement on an OLED screen.

```cpp
// Arduino Dual-Interrupt Quadrature Decoder for Printer Strips
const byte pinA = 2;
const byte pinB = 3;
volatile long encoderTicks = 0;

void setup() {
  Serial.begin(115200);
  pinMode(pinA, INPUT_PULLUP);
  pinMode(pinB, INPUT_PULLUP);
  attachInterrupt(digitalPinToInterrupt(pinA), handleA, CHANGE);
  attachInterrupt(digitalPinToInterrupt(pinB), handleB, CHANGE);
}

void handleA() {
  if (digitalRead(pinA) == digitalRead(pinB)) {
    encoderTicks++;
  } else {
    encoderTicks--;
  }
}

void handleB() {
  if (digitalRead(pinA) != digitalRead(pinB)) {
    encoderTicks++;
  } else {
    encoderTicks--;
  }
}

void loop() {
  static long lastTicks = 0;
  if (encoderTicks != lastTicks) {
    lastTicks = encoderTicks;
    float positionMM = (encoderTicks / 600.0) * 25.4; // Assuming 600 quadrature counts/inch
    Serial.print("Position: ");
    Serial.print(positionMM, 3);
    Serial.println(" mm");
  }
}
```

---

### B. Laser Printer Fuser Assembly: Flawless PCB Toner Transfer & Foil Laminator
Inside every laser printer is a **fuser unit** designed to melt plastic toner powder into paper fibers under intense heat and spring-loaded pressure.

```
Fuser Mechanical Cross-Section:
  [ Quartz Halogen Tube Lamp (~1,000 Watts) ]
                      |
                      v
      ====(Teflon-Coated Aluminum Tube)====  <--- Reaches 180°C - 205°C
                      |
               [ Workpiece ]  <--- (PCB Copper Board + Glossy Toner Paper)
                      |
      ====(Silicone Rubber Pressure Roller)====
                      ^
                      |
            [ Heavy Steel Springs ]
```

#### The Hack:
- In DIY PCB etching, ironing toner onto copper boards with a clothes iron is unreliable and uneven.
- By extracting the fuser assembly and wiring the internal halogen lamp through an AC solid-state relay (SSR) controlled by a K-type thermocouple or PID temperature controller, you create a motorized PCB toner applicator.
- Feed your copper clad board with printed laser glossy paper through the heated rollers at 185°C. In one 10-second pass, the fuser transfers 100% of toner onto the copper with zero trace smearing down to 6-mil traces.

---

### C. Laser Printer High-Voltage Power Supply (HVPS): Electrostatic Flocking & Powder Coating
Laser printers contain a specialized high-voltage power board that supplies:
- **Corona Wire / Charge Roller**: -5,000V to -6,000V DC at under 500 µA.
- **Developer Bias**: -300V to -600V DC.
- **Transfer Roller**: +1,000V to +3,000V DC.

#### Repurposing Exploits:
- **DIY Electrostatic Grass / Flocking Applicator**: Connect the negative 5kV output to a fine wire mesh sieve and positive ground to the workpiece coated with glue. Flocking fibers or synthetic grass become electrostatically charged and shoot downward at high speed, embedding vertically for hyper-realistic diorama scenery or velvet-lined luxury boxes.
- **Desktop DIY Powder Coating Gun**: Charge powder coat paint particles negatively as they spray past an electrode, causing them to wrap around grounded metal parts electrostatically for zero overspray.

---

### D. Flatbed Scanner Guides & Front-Surface Mirrors
- **Front-Surface Mirrors**: Ordinary household mirrors have their reflective silver coating on the *back* of glass, causing double-refraction "ghosting." Scanner mirrors are front-surface silvered (reflective coating on the top surface).
  - *Projects*: Laser light show galvo mirrors, 3D printer SLA beam deflecting optics, high-magnification microscope splitters.
- **Ground Steel Guide Rods**: Laser printers and copiers yield hardened 8mm, 10mm, and 12mm ground steel guide shafts that fit standard **LM8UU** or **LM10UU** linear ball bearings perfectly for building budget 3D printers, laser engravers, or CNC plotters.
