# 🌡️ Volume 7.5: Thermal & Exotic Energy Harvesting Electromechanics
*Solid-state Seebeck generators, reversed Stirling cryocoolers, and piezoelectric vibration harvesters.*

---

## 1. Thermoelectric Peltier Units (TEC) as Seebeck Generators (TEG)

```
Thermoelectric Seebeck Generation Mechanics:
         [ Hot Surface: Woodstove / Exhaust Pipe (200°C) ]
                                |
                                v
      +---------------------------------------------------+
      | Ceramic Substrate (Al2O3)                         |
      |   [ N-Type Bi2Te3 ]      [ P-Type Bi2Te3 ]        |  <--- Charge carriers migrate
      |         |                      |                  |       from hot to cold side
      | Ceramic Substrate (Al2O3)                         |
      +---------------------------------------------------+
                                |
                                v
       [ Cold Surface: Water Chilled / Heatsink (30°C) ]
                                |
                                v
               =====> Continuous DC Electricity!
```

### The Physics:
Thermoelectric coolers (Peltier modules, common in wine coolers, 12V portable car fridges, and computer CPU chillers) are completely reversible solid-state heat engines.
- When an electrical voltage is applied, heat moves from one face to the other (Peltier effect).
- When a temperature difference ($\Delta T$) is maintained across the two ceramic faces, charge carriers (electrons in N-type and holes in P-type Bismuth Telluride) migrate from the hot side to the cold side, generating continuous **DC electrical current (Seebeck effect)**.

---

### Step-by-Step Engineering Build: The Woodstove Power Station
During winter power outages, a wood-burning stove radiates massive heat, but homes remain dark.

```
Woodstove Thermoelectric Generator Stack:
  [Cast Iron Woodstove Top (reaches 220°C)]
                    |
      (Conductive Aluminum Spreader Plate)
                    |
      [4x TEC1-12706 / TEG Modules in Series]
                    |
      (Finned Aluminum Heatsink Bank)
                    |
      [Low-Draw 12V Cooling Fan (Powered by 1st module)]
                    |
                    v
  ====> Delivers 10W to 15W continuous power to USB Charger & LED Lighting!
```

1. **Module Selection**: True TEG modules (e.g., SP1848) utilize high-temperature solder rated up to 300°C. Standard cheap TEC1-12706 modules can be used, provided the hot face does not exceed **135°C** (to prevent low-temperature internal solder from melting).
2. **Thermal Clamping**:
   - Apply a micro-thin layer of high-temperature thermal paste to both ceramic faces.
   - Sandwich the modules between a 1/2" thick aluminum heat spreader plate (resting on the woodstove) and a massive finned aluminum CPU heatsink.
   - Clamp the stack together using stainless steel spring-loaded bolts. (The modules must remain under **150 to 200 PSI of mechanical compression** for efficient phonon and electron transport).
3. **Power Conditioning**:
   - A single module with $\Delta T = 80^\circ\text{C}$ generates approx. **2.5V to 3.5V at 1.0A to 1.5A**.
   - Wire four modules in series to produce **10V to 14V DC**.
   - Feed the output into an ultra-wide-input DC-DC buck/boost converter (e.g., based on the **LTC3780** or **XL6009**) set to a regulated 5V (for USB phone charging) and 12V (for running home emergency LED lighting and charging a LiFePO4 battery bank).

---

## 2. Miniature Stirling Cryocoolers (The Ultimate Thermodynamic Reversal)

```
Free-Piston Stirling Cryocooler:
  Stock Mode:
    [AC / DC Electrical Input] ===> [Linear Motor] ===> [Displacer / Piston] ===> Pulls tip to 77 Kelvin!
    
  Reversed Engine Mode:
    [External Heat Source on Tip] ===> [Thermal Expansion] ===> [Linear Alternator] ===> [AC Power Out]
```

### What Lies Inside High-End Thermal Gear:
Decommissioned military FLIR thermal cameras, satellite sensors, and high-altitude weather instruments contain a **Miniature Linear Free-Piston Stirling Cryocooler** (e.g., Ricor, Sunpower, AIM).
- Engineered with flexure bearings, ultra-pure helium gas charged to 30 atmospheres, and clearance seals with tolerances under 3 microns.
- Designed to run continuously for **50,000+ hours** without maintenance.

### The Two Exploits:
1. **Stock Exploitation (Extreme Cryogenics at Home)**:
   - Supplying 12V to 24V AC/DC to the linear motor drives the internal Stirling cycle, dropping the cold finger down to **77 Kelvin (-196°C / -321°F)** in under 5 minutes.
   - Condenses liquid nitrogen or liquid oxygen directly out of the ambient atmosphere onto the cold tip for home physics, superconductivity experiments, and cooling ultra-low-noise radio astronomy receivers.
2. **Reverse Heat Engine Exploitation**:
   - By applying external heat (a concentrated solar parabolic mirror or propane flame) to the cold finger while cooling the body, the thermodynamic cycle reverses.
   - The expansion of the internal helium gas drives the reciprocating piston back and forth across the linear alternator coil, producing **clean electrical power directly from concentrated sunlight or waste exhaust heat** with virtually zero mechanical wear.

---

## 3. Piezoelectric Vibration Energy Harvesters
- Discarded ultrasonic sensors and piezo buzzers mounted on flexible brass cantilevers with a small end-mass can be tuned to resonate at 50 Hz, 60 Hz, or 120 Hz.
- Clamped to the vibrating casings of industrial air conditioners, diesel generators, or bridge spans, the oscillating mechanical strain continuously flexes the PZT crystal lattice.
- Coupled through an ultra-low-leakage diode bridge and a capacitor storage circuit, it powers **perpetual, battery-free wireless environmental IoT sensor nodes** transmitting temperature and vibration telemetry indefinitely.
