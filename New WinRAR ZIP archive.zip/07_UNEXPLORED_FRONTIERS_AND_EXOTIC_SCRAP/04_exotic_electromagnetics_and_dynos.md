# 🧭 Volume 7.4: Exotic Electromagnetics, Dynos & Indestructible Resolvers
*Building alternator absorption dynamometers, decoding military synchro/resolvers, and Halbach array physics.*

---

## 1. The Automotive Alternator as an Engine Dynamometer (Dyno Bench)

```
Trunnion-Mounted Absorption Dyno Bench:
+------------------------------------------------------------------------+
| [Small Engine / Electric Motor under test]                             |
|          |                                                             |
|   (Flexible Coupler)                                                   |
|          |                                                             |
|          v                                                             |
| [Alternator Shaft] ====> Spins internal rotor                          |
|                                                                        |
| [Alternator Housing Mounted on Low-Friction Trunnion Bearings]         |
|   |--- Case is free to twist against a lever arm                       |
|   |                                                                    |
|   |===(1-Foot Torque Arm)====> [S-Beam Electronic Load Cell / Scale]   |
|                                                                        |
| [Hall Effect Sensor] ========> Reads Spindle RPM                       |
+------------------------------------------------------------------------+
```

### Why Inertia Dynos Fall Short:
Most DIY dynamometers are "inertia dynos"—they calculate power by timing how fast an engine can spin up a heavy steel drum. 
- *The Limitation*: An inertia dyno cannot hold an engine at a steady-state RPM (e.g., 3,500 RPM under 100% full throttle) to tune carburetor air-fuel ratios, map EFI fuel tables, or test cooling limits.
- **The Alternator Absorption Dyno Solution**:
  By mounting an automotive alternator in low-friction trunnion pillow blocks, the alternator acts as an **electronically controllable electromagnetic brake**.

---

### Step-by-Step Engineering Build:
1. **Trunnion Mounting**:
   - Fabricate a cradle that clamps the front and rear bearing collars of the alternator into two external pillow-block ball bearings. The alternator case must be free to swivel on its shaft axis.
2. **The Torque Arm**:
   - Bolt a rigid aluminum or steel bar to the alternator housing, extending out horizontally by exactly **1.000 Foot (12 inches / 0.3048 m)** from the centerline of the shaft.
   - Rest the tip of this arm on an electronic **S-Beam Load Cell** connected to an HX711 24-bit ADC amplifier module.
3. **Electronic Load Absorption Control**:
   - Supply the alternator rotor field coil with variable current via a high-current logic-level MOSFET driven by an Arduino PWM pin.
   - Connect the alternator's B+ and ground output to an external **high-power electrical dump load** (e.g., a bank of 12V 1000W immersion heating elements submerged in a 5-gallon bucket of water).
4. **Data Acquisition & Horsepower Math**:
   - An optical or magnetic Hall-effect sensor reads shaft RPM.
   - The Arduino reads torque force in pounds ($F$) from the load cell:
     $$\text{Torque (ft-lbs)} = F \times 1.0 \text{ ft}$$
     $$\text{Horsepower} = \frac{\text{Torque} \times \text{RPM}}{5,252}$$
5. **Operation**:
   - Start the test engine at idle.
   - Increase field current PWM via a software slider. The magnetic resistance increases smoothly, pulling down engine RPM under wide-open throttle to measure true continuous torque curves across the entire powerband.

---

## 2. Military & Aerospace Synchros and Resolvers

```
Resolver Internal Electromagnetic Architecture:
           [Reference AC Excitation (2 kHz - 10 kHz Sine Wave)]
                                  |
                                  v
                        [Rotor Primary Coil]
                                  |
                      (Rotating Magnetic Field)
                                  |
            +---------------------+---------------------+
            |                                           |
            v                                           v
[Stator Coil 1: Sine Channel]               [Stator Coil 2: Cosine Channel]
(Output = V_ref * Sin(θ))                   (Output = V_ref * Cos(θ))
```

### Why Optical Encoders Fail & Resolvers Survive:
Standard modern optical encoders rely on glass discs printed with microscopic lines and infrared LEDs. In harsh environments (metal grinding dust, hot oil, shock loads, moisture, freezing temperatures), optical encoders quickly fail.
- Discarded military aircraft, radar pedestals, marine steering systems, and heavy industrial CNC machinery yield **Resolvers and Synchros**.
- **The Hardware**: A resolver is an all-metal, brushless rotary transformer containing zero silicon chips, zero LEDs, and zero glass. It can operate submerged in boiling oil, under high radiation, and withstand **100G of mechanical shock**.

---

### Demodulating a Resolver with an Arduino / ESP32:
A resolver outputs two carrier signals whose amplitudes represent the Sine and Cosine of the shaft angle ($\theta$):
1. **Excitation**: Feed the rotor reference winding with an audio-frequency AC sine wave (typically 2 kHz to 5 kHz at 2V to 5V RMS) generated by an ESP32 DAC pin.
2. **Reading Signals**:
   - Read the peak-to-peak amplitude of the two stator windings using precision rectifier op-amps or direct high-speed analog ADC sampling:
     $$V_{\sin} = A \cdot \sin(\theta)$$
     $$V_{\cos} = A \cdot \cos(\theta)$$
3. **Angle Calculation**:
   - Compute absolute rotational angle instantaneously with the four-quadrant inverse tangent:
     $$\theta = \text{atan2}(V_{\sin}, V_{\cos})$$
4. **The Exploits**:
   - **Indestructible Lathe/Mill Spindle Angle Indexer**: Tracks spindle angle down to 0.01° for single-point threading and milling cross-holes in messy shop environments.
   - **Severe-Environment Solar / Antenna Elevation Rotor**: Operates outside in blizzards, desert sandstorms, and hail for decades without maintenance.

---

## 3. Halbach Magnetic Arrays from Microwave Magnetron Rings
- When disassembling microwave magnetrons, you extract two massive ceramic ferrite (or sintered neodymium) ring magnets.
- **The Halbach Miracle**:
  - In normal magnets, flux lines emerge from the North face and return symmetrically to the South face.
  - By cutting magnet segments and arranging their magnetic poles in a cyclic 90° spatial phase sequence ($\rightarrow, \uparrow, \leftarrow, \downarrow$), the magnetic field on one side of the array **doubles in strength**, while the field on the opposite side is **completely canceled out to near-zero**.
- **Repurposing Exploits**:
  - **Frictionless Magnetic Linear Bearings**: Halbach arrays suspended over high-conductivity thick copper or aluminum plates induce strong opposing eddy currents that create **passive magnetic levitation** as velocity increases.
  - **Ultra-High Efficiency Ironless Coreless Motors**: Generates maximum magnetic flux directly through copper air-core coils without needing heavy iron stator teeth, eliminating magnetic cogging torque completely.
