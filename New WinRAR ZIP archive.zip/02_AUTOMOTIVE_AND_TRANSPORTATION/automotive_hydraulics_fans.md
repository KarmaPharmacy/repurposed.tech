# 💨 Volume 2.3: Automotive Hydraulics, High-Flow Blowers & Actuators
*Harvesting 2,000 PSI ABS hydraulic pumps, 3,000 CFM radiator fans, and electronic throttle servos.*

---

## 1. ABS Hydraulic Pump Modules: Micro-Hydraulic Powerhouses

```
ABS Pump Assembly Cutaway:
  +-----------------------------------------------------------+
  | [12V Heavy PMDC Motor]                                    |
  |            |                                              |
  |       (Eccentric Cam)                                     |
  |            |                                              |
  |            v                                              |
  | [Dual Miniature Piston Pumps inside Machined Aluminum Block]
  |            |                                              |
  |            v                                              |
  | ====> Produces 1,500 to 2,200 PSI Hydraulic Pressure!     |
  +-----------------------------------------------------------+
```

### What Makes Them Remarkable:
Every modern car Anti-lock Braking System (ABS) module contains a precision 12V DC electric motor mounted to a solid billet aluminum valve block.
- Inside the aluminum block is an eccentric camshaft that drives two opposing, hardened steel micro-pistons.
- These pumps are engineered to generate instantaneous hydraulic pressures between **1,500 PSI and 2,200 PSI (100 to 150 Bar)** to actuate brake calipers during emergency stops.

### Creative Repurposing Exploits:
- **Desktop DIY Hydraulic Press / Metal Forming Brake**:
  - Plumb the high-pressure output of an ABS pump block into a small single-acting hydraulic ram (e.g., from an 8-ton bottle jack or micro cylinder).
  - Actuated by a 12V foot switch, this compact setup easily generates 2 to 5 tons of pressing force to press bearings, punch sheet metal holes, or bend 1/4" steel brackets on a kitchen tabletop.
- **Scale-Model Hydraulic Excavator / Battlebot Actuators**:
  - RC and combat robotics builders use salvaged ABS pumps as the central hydraulic power unit for heavy-lifting robotic digging arms and hydraulic crushing jaws.

---

## 2. Automotive Radiator Fans & HVAC Blowers

```
Cooling Fan vs. Squirrel-Cage Blower:
  Axial Radiator Fan:                 Centrifugal HVAC Blower:
    - High CFM (2,000 - 3,500 CFM)      - High Static Pressure
    - Low Static Pressure               - Overcomes Duct & Filter Resistance
    - Moves Massive Free Air Volume     - Ideal for Dust Filters & Forges
```

### A. High-CFM Radiator Cooling Fans:
- **Specs**: 12V–14V DC, 10A to 25A draw. Fully weather-sealed permanent magnet DC motor spinning high-efficiency curved aerodynamic blades.
- **Airflow**: 1,800 to 3,500 Cubic Feet per Minute (CFM).
- **Repurposing**:
  - **Shop Spray Booth / Fume Evacuation**: Mount into a window frame with a standard furnace air filter to evacuate volatile paint and resin fumes outside in seconds.
  - **DIY Hovercraft Lift Fan**: Mount vertically inside a duct with an aerodynamic skirt. The massive airflow creates the air cushion required to lift a 150 lb rider off the ground over smooth concrete or grass.

### B. HVAC Centrifugal "Squirrel-Cage" Blowers:
- **Specs**: 12V DC multi-speed motor coupled to a forward-curved squirrel cage impeller.
- **Why It Matters**: Unlike axial fans that stall when encountering resistance, centrifugal blowers generate substantial **static pressure**—meaning they can force air through tight ducts, filters, and coal beds without losing velocity.
- **Repurposing**:
  - **Blacksmith Forge Blast Air Supply**: Connect the blower outlet to a 2" steel pipe leading into the bottom of a charcoal or coal forge. A simple 12V PWM motor controller provides precise air velocity adjustment to heat forge iron up to white-hot welding temperatures (2,300°F+).
  - **Woodworking Downdraft Sanding Table**: Mount underneath a pegboard tabletop to suck toxic wood dust downward directly into a collection bag before it reaches your lungs.

---

## 3. Electronic Drive-by-Wire Throttle Bodies (ETB)
Modern fuel-injected engines no longer connect the gas pedal to the intake manifold with a cable; they use an **Electronic Throttle Body**.
- **Internal Hardware**: High-speed, high-torque 12V DC servo motor, multi-stage reduction gears, heavy return spring, and dual redundant Hall-effect position sensors (TPS).
- **Repurposing**:
  - **Automated Wood Stove / Smoker Draft Damper**: Couple the throttle body to your barbecue smoker or wood-burning stove intake. An ESP32 reading a meat or pit thermocouple modulates the throttle plate from 0% to 100% to maintain cooking temperatures within ±1°F for 16-hour brisket smokes.
  - **Emergency Pneumatic Air-Shutoff Valve**: Acts as an instant fail-safe intake choke for diesel engines or industrial blowers to prevent engine runaway.
