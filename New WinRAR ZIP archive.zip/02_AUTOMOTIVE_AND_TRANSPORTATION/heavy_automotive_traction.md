# ⚡ Volume 2.2: Heavy Automotive Electromechanics & Traction
*Converting alternators into 5 HP brushless beasts, EPS columns into direct-drive sim wheels, and taming starter motors.*

---

## 1. The Car Alternator: From Generator to High-Power Brushless Motor

```
Alternator BLDC Conversion Topology:
+------------------------------------------------------------------------+
|                                                                        |
|  [Rotor Field Slip Rings] <--- External 12V DC (Field Excitation)      |
|                                                                        |
|  [3-Phase Stator (U, V, W)] <--- (48V–72V 100A 3-Phase E-Bike ESC)     |
|          |                                                             |
|          +==================> Delivers 5 to 7 HP @ 8,000+ RPM!        |
+------------------------------------------------------------------------+
```

### Why It Works:
A standard automotive alternator is mechanically and electromagnetically identical to an industrial 3-phase Permanent Magnet Synchronous Motor (PMSM), with one key difference: instead of permanent magnets on the rotor, it uses an **electromagnet (field coil)** fed through two carbon brushes and slip rings.

---

### Step-by-Step Conversion Procedure:
1. **Teardown & Rectifier Removal**:
   - Unbolt the through-bolts holding the alternator aluminum end-housings together.
   - Locate the internal diode rectifier bridge (usually 6 high-current press-fit diodes on a curved aluminum heat sink).
   - **Desolder or clip the three stator phase wires** from the rectifier. Discard or bypass the diode bridge and voltage regulator.
   - Solder three heavy, high-strand silicone wires (10 AWG or 8 AWG) directly to the three stator phase leads. Bring them outside the case as phases `U`, `V`, and `W`.
2. **Rotor Field Excitation**:
   - The two slip-ring brushes feed the claw-pole rotor coil.
   - Connect a switchable, fused 12V DC power source across these brushes. This energizes the rotor, creating alternating North and South magnetic poles across the rotor claws.
3. **Electronic Speed Controller (ESC) Connection**:
   - Connect the three heavy stator wires to a standard 48V to 72V, 100A+ brushless motor speed controller (such as a generic e-bike controller or high-power VESC).
4. **Operation**:
   - Energize the rotor with 12V DC.
   - Apply throttle to the ESC.
   - The converted alternator spins up with breathtaking speed, producing up to **5,000 Watts (approx. 6.7 Horsepower)** of clean, smooth rotary power.

---

### Creative Engineering Projects:

#### A. Electric Go-Kart / Minibike Traction Drive
- Couple the modified alternator to a go-kart live axle via a 4:1 or 5:1 chain sprocket.
- Powered by a 48V lithium-ion battery pack, the motor propels an adult driver up to 35–45 MPH with immense low-end punch.

#### B. Off-Grid Engine-Driven Stick / TIG Welder
- Couple an unhacked alternator to a 6.5 HP horizontal-shaft gas engine (e.g., Predator 212cc) via a 2:1 speed-up pulley.
- Supply adjustable 0–12V excitation current to the rotor via a manual potentiometer.
- Connect heavy 2 AWG welding leads directly to the alternator's B+ output stud and chassis ground.
- Turning the potentiometer dial adjusts welding current smoothly from **40 Amps up to 140 Amps DC**—producing butter-smooth DC stick welding arcs in the field with zero mains power.

---

## 2. Electric Power Steering (EPS) Columns: Direct-Drive Sim Racing Wheel

```
EPS Force Feedback Sim Racing Architecture:
[PC Running Assetto Corsa / iRacing]
               |
         (USB Telemetry)
               v
[STM32 "BluePill" Running OpenFFB Firmware]
               |
         (PWM + Direction)
               v
[BTS7960 43A Driver or Discrete MOSFET Inverter]
               |
         (High-Current 12V)
               v
[EPS Steering Column Motor] ===> [Full-Size Race Steering Wheel]
*(Delivers 25-30 Nm Realistic Force Feedback Torque)*
```

### Why Commercial Sim Racers Fear This Hack:
High-end "Direct-Drive" force feedback steering wheels (Fanatec Podium, Simucube) cost between **$1,200 and $2,500**.
- Modern compact cars (e.g., Toyota Prius, Opel Corsa B/C, Nissan Versa) use column-mounted Electric Power Steering (C-EPS).
- An EPS unit consists of a high-power brushless servo motor coupled to the steering shaft through a precision, high-efficiency worm reduction gear, equipped with a torsion-bar torque sensor.
- A salvaged EPS column from a local auto scrap yard costs **$30 to $50**.

### Repurposing into an OpenFFB Racing Simulator:
1. **Mechanical Mounting**: Fabricate a heavy steel plate clamping the EPS housing to your sim rig or desk frame. Bolt a real aftermarket racing wheel directly to the splined input shaft.
2. **Electronics**:
   - Microcontroller: STM32F103C8T6 ("BluePill") running open-source **OpenFFB** or **MMOS** firmware.
   - Interfacing: The STM32 reads in-game physics telemetry (tire slip, curb rumble, weight transfer) over USB and calculates exact real-time counter-steering torque.
3. **Power Delivery**: Drive the EPS motor using a heavy 12V 50A server power supply through a BTS7960 H-Bridge module.
4. **Performance**: Produces **20 to 30 Nm of instantaneous steering torque**—enough force to physically rip the wheel out of your hands if you clip a curb at 150 MPH.

---

## 3. Automotive Starter Motors: Taming the Series-Wound Beast

```
Starter Motor Motor Characteristics:
  - Architecture: Series-Wound DC (Field coils in series with armature)
  - Voltage: 12V DC
  - Current: 150A to 300A continuous; 600A+ locked-rotor stall!
  - Output Power: 1.5 to 2.5 kW (~2 to 3.5 HP)
  - Duty Cycle: Strictly Intermittent (30 seconds ON / 5 minutes cooling)
```

### Safety & Mechanical Realities:
- **No-Load Runaway Hazard**: In a series-wound motor, magnetic field strength decreases as motor speed increases. If powered without any mechanical load attached, a starter motor will accelerate exponentially until centrifugal force **explodes the armature windings outward against the casing**. ALWAYS keep starter motors mechanically loaded.
- **Bushing Conversion**: The nose cone of a starter motor often lacks an internal bearing, relying on a bronze bushing pressed into the car's engine bellhousing. When salvaging a starter for standalone projects, select models with a **self-contained snout bearing**, or machine a custom bronze support carrier.

### Repurposing Exploits:
- **Ultra-High-Pull Off-Road Recovery Winch**: Mount a starter motor through a 100:1 planetary or worm reduction box to create an unstoppable 8,000 lb pulling winch for trailers and tractors.
- **Short-Track Dragster Launch Drive**: Delivers instantaneous, explosive torque off the line for junior dragsters and custom experimental vehicles.
