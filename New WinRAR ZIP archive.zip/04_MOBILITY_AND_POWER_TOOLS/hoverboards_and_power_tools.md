# 🛹 Volume 4.1: Mobility Electromechanics & Power Tools
*Reprogramming hoverboard STM32 controllers, hacking 30-pole BLDC hub motors, drill planetary gearboxes, and 125k RPM vacuum turbines.*

---

## 1. Hoverboard Hub Motors & Controller Hacking

```
Hoverboard Hardware Architecture:
+--------------------------------------------------------------+
| [36V 4.4Ah 18650 Battery Pack]                               |
|                     |                                        |
|                     v                                        |
|  [Mainboard: STM32F103 MCU + Dual 3-Phase Inverter MOSFETs]  |
|          |                                   |               |
|          v                                   v               |
|  [Left 350W Hub Motor]              [Right 350W Hub Motor]   |
|  (30 Neodymium Poles)               (30 Neodymium Poles)     |
+--------------------------------------------------------------+
```

### Why Hoverboard Scrap is a Maker Goldmine:
Hoverboards offer an unbeatable price-to-performance ratio. A scrap hoverboard yields:
- **Two 350-Watt Brushless Hub Motors**: Built directly into solid rubber or pneumatic wheels, packing 30 sintered neodymium magnets and 3 built-in Hall-effect sensors.
- **A Complete Dual-Motor Inverter Controller**: Driven by an **ARM Cortex-M (STM32F103 or GD32F103)** microcontroller connected to 12 high-power MOSFETs capable of switching 15A to 20A per phase at 36V–42V.
- **A 36V 10S2P Lithium-Ion Battery Pack**: 20 high-drain 18650 cells with integrated Battery Management System (BMS).

---

### The Open-Source Controller Hack (`hoverboard-firmware-hack`):
You do not need to discard the motherboard or buy expensive aftermarket motor drivers!

```
ST-Link Programming Header on Mainboard:
  [GND]   ---> ST-Link GND
  [SWDIO] ---> ST-Link SWDIO
  [SWCLK] ---> ST-Link SWCLK
  [3.3V]  ---> ST-Link 3.3V (Only when main battery is disconnected!)
```

1. **Flashing Procedure**:
   - Solder a 4-pin header to the programming pads labeled `GND`, `DIO`, `CLK`, and `3.3V` on the hoverboard mainboard.
   - Connect an inexpensive **ST-Link V2 programmer** ($4 online) to your PC.
   - Clone the open-source **`hoverboard-firmware-hack`** repository (available on GitHub).
   - In `config.h`, choose your preferred control input method:
     - `CONTROL_UART`: Control speed and steering via serial commands from an Arduino, Raspberry Pi, or ESP32.
     - `CONTROL_PPM`: Plug directly into a standard RC hobby drone or car receiver.
     - `CONTROL_ADC`: Wire directly to two analog thumb throttles or potentiometers.
   - Flash the firmware using OpenOCD or STM32CubeProgrammer.
2. **The Result**: You now have a complete, professional-grade dual-channel 700W motor drive platform with regenerative braking and Field-Oriented Control (FOC) for $0 in driver costs.

---

### Creative Engineering Projects:

```
Electric Powered Yard Cart / Wheelbarrow:
  +-------------------------------------------------------------+
  | [Dual Hoverboard Hub Motors as Front Wheels]                |
  |         |                                                   |
  | [Reprogrammed Mainboard mounted under steel tray]           |
  |         |                                                   |
  | [Thumb Throttle & Reverse Switch on Left/Right Handles]     |
  |                                                             |
  | ====> Hauls 350 lbs of gravel up a 25° incline effortlessly!|
  +-------------------------------------------------------------+
```

#### A. Autonomous Heavy Rover / AGV (Outdoor Robot Platform)
- Mount the two hoverboard wheels to a rectangular aluminum or plywood chassis with two rear caster wheels.
- Send simple ASCII serial velocity commands from a Raspberry Pi running ROS (Robot Operating System) or an Arduino:
  ```
  Speed: 150, Steer: -50\n
  ```
- Easily carries 100+ lbs of payload over grass, rocks, and dirt roads.

#### B. ODrive-Powered Robotic Arm & Quadruped Leg Joints
- Remove the rubber tire from a hoverboard hub motor to expose the bare aluminum rim.
- Attach an off-axis magnetic rotary encoder (such as the **AS5600** or **AMT102**).
- Connect to an **ODrive motor controller**: The hub motor transforms into a direct-drive, zero-backlash robotic actuator capable of holding position down to 0.01° with massive holding torque.

---

## 2. Cordless Drills: Modular Powertrains for Combat Robotics

```
Drill Planetary Transmission:
  [Mabuchi 550 DC Motor] ---> (Sun Gear 1) ===> [Planetary Stage 1 (6:1)]
                                                        |
                                                        v
                              [Planetary Stage 2 (6:1)] ===> High-Torque 1/2" Spindle
                              *(Total Reduction: 36:1)*
```

### The Combat Robotics Rite of Passage:
For decades, combat robot builders in the 12 lb (Hobbyweight) and 30 lb (Featherweight) classes built drivetrains from cheap cordless drills (Harbor Freight, Black & Decker, Ryobi).
- **Why**: A complete drill provides a high-torque 550-size motor, a hardened steel 2-stage or 3-stage planetary gearbox, an output bearing, and a keyless chuck all in one compact cylindrical assembly.

#### Locking the Clutch (Mandatory for High Load):
The adjustable torque collar on a drill will slip under aggressive acceleration or wheel impacts.
1. Unscrew the front chuck (remember: chuck retention screws inside the jaw are **reverse-threaded / left-hand thread**).
2. Remove the plastic clam-shell and unscrew the gearbox ring collar.
3. Extract the small steel clutch ball bearings and springs.
4. Fill the ball pockets with high-strength structural epoxy (J-B Weld) or insert solid steel roll-pins, then re-tighten the collar. The transmission is now locked solid into 100% direct-drive mode.

---

## 3. Digital Brushless Vacuum Turbines (Dyson Type)
Modern bagless cordless stick vacuums utilize custom brushless switched-reluctance or high-frequency PMSM motors.
- **Insane Velocity**: Spins at **100,000 to 125,000 RPM**.
- **Impeller**: Precision CNC-machined aerodynamic mixed-flow impeller.

### Repurposing Exploits:
- **Instant Desktop Thermoforming Vacuum Former**: Standard shop vacuums have slow air evacuation rates. A digital vacuum motor creates instantaneous, intense negative pressure—drawing heated plastic sheets down over intricate 3D-printed patterns before the plastic can cool.
- **Micro Wind Tunnel**: Testing aerodynamic drag on miniature airfoils and model rockets.
