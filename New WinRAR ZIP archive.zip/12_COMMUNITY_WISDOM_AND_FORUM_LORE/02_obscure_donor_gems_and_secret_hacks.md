# 💎 Volume 12.2: Obscure Donor Gems & Underground Maker Exploits
*The hidden high-value treasures inside mundane appliances that 99% of people throw away.*

---

## 1. Nichrome Wire Harvesting (Hairdryers, Toasters, Space Heaters)

```
Nichrome (80/20 NiCr) Harvesting Anatomy:
  [Dead Hair Dryer / Toaster / Space Heater]
                     |
  (Extract Mica Insulating Card Core)
                     |
  ====> Yields 15 to 30 feet of heavy-gauge Nichrome Resistance Wire!
```

### Why Nichrome is Irreplaceable:
Nichrome (80% Nickel, 20% Chromium) forms a protective chromium oxide surface layer when heated, allowing it to glow orange-hot (**800°C to 1,150°C**) without oxidizing, corroding, or melting in air.
- Buying spools of specialized Nichrome wire online costs $15–$25 plus shipping.
- A single discarded 1,875-Watt hair dryer or $5 thrift store toaster yields **15 to 30 feet of heavy-gauge coiled Nichrome wire**.

### High-Value Repurposing Exploits:
- **The Precision Hot-Wire CNC Foam Cutter**:
  - Stretch a 24-inch length of salvaged hair dryer Nichrome wire between two spring-tensioned arms.
  - Power with a 12V DC supply (or variable bench PSU) at approx. **1.5A to 2.5A**.
  - The wire heats up to an invisible 200°C.
  - Cuts through dense Extruded Polystyrene (XPS) insulation foam, architectural model blocks, and RC airplane wings with surgical precision, leaving smooth, glass-like cut faces with **zero crumbly foam dust**.
- **Impulse Heat Sealer for Custom Packaging**:
  - Mount a straight Nichrome wire under high-temperature PTFE (Teflon) tape.
  - Pulsing 12V through the wire for 0.8 seconds melts and hermetically seals plastic mylar bags, vacuum pouches, and custom electronics blister packs.

---

## 2. The HP / Dell Server Power Supply 12V 100A Conversion

```
Server Power Supply Pinout Hack (HP Common Slot 750W / 1200W):
  +-----------------------------------------------------------+
  | [Heavy Gold +12V DC Output Bus Blade]                     |
  |                                                           |
  | [Gold Signal Ribbon Edge Connector]                       |
  |   |--- Pin 33 (PS_ON)   ---+                              |
  |   |--- Pin 36 (PS_KILL) ---+===(Jumper Wire)===> [GND]    |
  |                                                           |
  | [Heavy Gold GND DC Output Bus Blade]                      |
  |                                                           |
  | ====> Wakes up unit: PUMPS 62A to 100A at 12.2V DC!       |
  +-----------------------------------------------------------+
```

### Why Buy a Bench Supply When Server PSUs Are Free?
Commercial 12V 50A benchtop lab power supplies cost hundreds of dollars.
- Discarded enterprise blade servers (HP ProLiant DL380, Dell PowerEdge) yield **"Common Slot" power supply units (PSUs)** rated for **750W to 1,200W** with 80-Plus Platinum efficiency.
- Built to run 24/7/365 under extreme server room thermal loads.

### The 10-Second Modification:
1. Locate the small gold logic pads on the rear edge connector.
2. Solder a 1 kΩ resistor (or direct jumper wire) between **Pin 33 (`PS_ON`), Pin 36 (`PS_KILL`), and Ground**.
3. Plug in the AC mains cord. The green LED lights up, and the unit delivers **12.2V DC at up to 100 Amps continuous**—the ultimate power station for testing high-current windshield wiper motors, cordless drill combat robots, and LiFePO4 battery chargers.

---

## 3. Microwave Oven Door Interlock Switch Banks (Omron 15A Snaps)
- Microwave ovens feature a fail-safe mechanical latch interlock containing **three distinct snap-action microswitches**:
  1. *Primary Interlock Switch*: Normally Open (NO), 15A rating.
  2. *Secondary Interlock Switch*: Normally Open (NO), 15A rating.
  3. *Monitor Switch*: Normally Closed (NC) heavy shorting switch.
- These switches use hardened silver-cadmium contacts designed to interrupt full AC mains current reliably over **100,000 cycles**.
- *Repurposing*: Never purchase cheap plastic limit switches for large CNC routers, milling machines, or automated security gates. Microwave door switches provide rock-solid, debounce-resistant contact sensing that will outlive the machine tool.

---

## 4. Automobile Alternator Overrunning Decoupler (OAD) Pulleys
- Modern vehicle alternators (found on Honda, Toyota, VW, Ford) do not use solid steel belt pulleys; they use **OAD (Overrunning Alternator Decoupler) pulleys**.
- Inside the pulley is a **miniature internal sprag clutch and torsional torsion spring**.
- It allows the pulley to drive the alternator in the forward direction, but **freewheels smoothly if the belt decelerates suddenly**, dampening engine crankshaft harmonics.
- *Repurposing*: The ultimate indestructible overrunning clutch for pedal-powered generators, wind turbine mechanical diodes, and starter back-drive protection.
