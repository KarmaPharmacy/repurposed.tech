# 🧠 Volume 12.1: Battle-Tested Forum Lore & Unwritten Scrapper Rules
*Synthesized wisdom, hard-learned mistakes, and fatal traps from Reddit, EEVblog, Practical Machinist, and Endless-Sphere.*

---

## 1. The Treadmill Motor Lathe Traps (Machinist Forum Consensus)

Repurposing a permanent-magnet DC (PMDC) treadmill motor to drive a metal or wood lathe is the most popular shop conversion in the maker world. However, threads across *Practical Machinist* and *The Hobby-Machinist* detail the classic mistakes that ruin machines:

```
+-------------------------------------------------------------------------+
| The 5 Deadly Sins of Treadmill Lathe Conversions:                       |
|                                                                         |
| 1. The "Peak vs. Continuous" HP Lie (Don't trust 3.0 HP labels!)        |
| 2. Direct 1:1 Coupling (Guarantees zero low-RPM threading torque)       |
| 3. Conductive Cast-Iron Dust Ingestion (Destroys open-frame armatures)   |
| 4. The "Instant Dynamic Braking" Catastrophe (Unscrews threaded chucks) |
| 5. Reversing Under Rotation (Destroys controllers & strips gearboxes)   |
+-------------------------------------------------------------------------+
```

### Trap 1: The Manufacturer "Treadmill Horsepower" Deception
- Treadmill manufacturers print *"2.5 HP"* or *"3.0 HP"* on motor labels running off standard 120V 15-Amp household outlets.
- **The Math**: $120\text{V} \times 15\text{A} = 1,800\text{ Watts}$. Even with 100% electrical efficiency:
  $$\frac{1,800\text{ Watts}}{746\text{ Watts/HP}} \approx \mathbf{2.41\text{ HP Maximum Theoretical Input!}}$$
- After accounting for motor heat and controller efficiency ($\sim 75\%$), true continuous output is **1.0 to 1.5 Horsepower**. 
- *Rule*: Size your metal lathe cuts for a 1.25 HP motor, not a 3 HP industrial drive.

### Trap 2: Direct 1:1 Drive Eliminates Threading Torque
- Beginners often couple the treadmill motor 1:1 directly to the lathe spindle.
- Treadmill motors produce their rated torque and cooling airflow between **2,500 and 4,500 RPM**.
- When you slow the motor down electronically to **100–200 RPM** for single-point screw threading or large-diameter facing:
  - Back-EMF drops, torque plummets, and the built-in fan barely moves air. The motor overheats and stalls on light cuts.
- *The Unwritten Fix*: **Always retain mechanical step pulleys or a 3:1 / 4:1 jackshaft reduction**. Let the motor spin happily at 1,500 RPM while the mechanical belt reduction steps spindle speed down to 300 RPM, multiplying torque at the cutting tip by $4\times$.

### Trap 3: Conductive Metal Dust Ingestion (Open-Frame ODP Motors)
- Most treadmill motors are **Open Drip Proof (ODP)** with large ventilation slots.
- Cast iron shavings, steel swarf, and coolant mist will be sucked inside by the internal fan. Conductive iron dust bridges the commutator bars, destroying the carbon brushes and shorting the armature.
- *The Fix*: Fabricate a cylindrical sheet metal or 3D-printed filtered shroud over the motor's rear intake vents with washable open-cell foam filter media.

### Trap 4: The Instant-Brake Threaded Chuck Catastrophe
- Setting a DC motor controller for instantaneous dynamic braking stops the spindle in 0.1 seconds.
- On lathes with **threaded spindle noses** (vintage South Bend, Atlas, Logan), the massive rotational inertia of a heavy 6-inch steel chuck and workpiece spinning at 1,500 RPM will **violently unscrew the chuck off the spindle**, sending a 25 lb spinning steel projectile flying toward the operator.
- *The Rule*: Use gentle dynamic deceleration (2 to 3 seconds) or a mechanical foot brake.

### Trap 5: Reversing Polarity While Rotating
- Reversing motor leads via a DPDT switch while the armature is spinning creates a massive back-EMF dead short across the controller's H-bridge or SCRs, vaporizing the silicon output stage instantaneously.
- *The Rule*: Always wire an **electrical or mechanical interlock**: The reverse switch must pass through a center-OFF detent, and the operator must bring the speed potentiometer to zero before changing direction.

---

## 2. The Component Hoarding Trap (EEVblog Forum Consensus)

Every electronics novice falls into the same trap: spending 4 hours desoldering hundreds of 1/4-watt carbon film resistors, 1N4148 diodes, and tiny ceramic disk capacitors from broken TV chassis.

```
THE REALITY OF ELECTRONICS SCRAPPING:
+-------------------------------------------------------------------------+
| NEVER DESOLDER (Fool's Gold):        | ALWAYS HARVEST (The True Gold):  |
| ------------------------------------ | -------------------------------- |
| - 1/4W Resistors ($0.005 new)        | - Heavy Aluminum Extruded Sinks  |
| - Standard Diodes & Signal BJTs      | - Linear Mains Transformers      |
| - Electrolytic Capacitors (Dry out!) | - TO-220 / TO-247 Power MOSFETs  |
| - Custom Masked / ASICs Chips        | - Industrial Microswitches (15A) |
| - Surface-Mount 0603/0805 Passives   | - Server Power Supplies (12V 50A)|
| - Multi-Layer Board Components       | - Heavy Nichrome Heating Coils   |
+-------------------------------------------------------------------------+
```

### Why Electrolytic Capacitors Are Almost Always Trash:
- Electrolytic capacitors contain liquid/gel electrolyte that dries out over 10–15 years, especially when subjected to heat inside power supplies and amplifiers.
- A capacitor may measure correct capacitance on a cheap multimeter, but under high frequencies its **Equivalent Series Resistance (ESR)** has skyrocketed, causing circuit failure.
- Unless you verify with an ESR meter, using salvaged electrolytic caps in new projects introduces unpredictable phantom bugs that take days to diagnose.

---

## 3. Hoverboard BLDC Phase & Hall Wire Mapping (Endless-Sphere Wisdom)

When pairing a salvaged hoverboard hub motor with an aftermarket e-bike controller or VESC, wire colors almost never match. 
- You have 3 heavy Phase wires (e.g., Blue, Green, Yellow) and 3 thin Hall sensor wires (Blue, Green, Yellow).
- There are **36 possible wiring combinations** ($6 \text{ Phase} \times 6 \text{ Hall}$). Only **6 combinations work** (3 forward, 3 reverse), and only **1 combination provides optimal efficiency and lowest noise**.

```
Systematic Endless-Sphere 6-Step BLDC Mapping Protocol:
1. Connect Hall VCC (+5V Red) and Hall GND (Black) correctly.
2. Pick any Phase connection (Yellow-Yellow, Green-Green, Blue-Blue).
3. Try Hall combinations systematically while monitoring current with an ammeter:
   - Wrong Combination: Motor shudders, growls, vibrates, or draws > 4 Amps at no-load.
   - False True: Motor spins fast but draws 3 Amps and runs hot.
   - OPTIMAL TRUE COMBINATION: Motor spins whisper-quiet, starts smoothly from zero,
     and draws UNDER 1.0 Amp at full no-load throttle!
```
