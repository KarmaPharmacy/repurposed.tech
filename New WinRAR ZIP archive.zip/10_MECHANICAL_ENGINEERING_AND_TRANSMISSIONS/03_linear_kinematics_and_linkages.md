# ⚙️ Volume 10.3: Linear Kinematics, Leadscrews & Linkage Mechanisms
*Preloading anti-backlash nuts, four-bar kinematics, Peaucellier straight-line linkages, and Scotch yokes.*

---

## 1. Leadscrews vs. Recirculating Ballscrews

```
Mechanical Comparison:
  ACME Leadscrew (Trapezoidal 29°/30°):      Recirculating Ballscrew:
     [ Steel ACME Thread ]                     [ Hardened Gothic Raceways ]
              |                                             |
     [ Bronze / Delrin Nut ]                   (Recirculating Steel Ball Bearings)
     - Sliding Friction                        - Rolling Friction
     - Efficiency: 30% - 50%                   - Efficiency: 90% - 98%
     - Often Self-Locking                      - Will Back-Drive Under Gravity!
     - Requires Spring Anti-Backlash           - Zero Backlash via Ball Oversizing
```

### Eliminating Backlash on Salvaged ACME Screws:
When reversing direction on a standard leadscrew (from power seats, treadmills, or 3D printers), mechanical play (backlash) between the screw flanks causes an immediate dead-zone of **0.2 mm to 1.0 mm**.
- **The Spring-Loaded Split Nut Solution**:
  ```
  Anti-Backlash Preload Mechanism:
    [Nut Half 1] <--- [Stiff Die Spring] ---> [Nut Half 2]
         |                                         |
    (Pushes left against thread flank)      (Pushes right against opposite flank)
  ```
  - Cut or machine two identical Delrin or brass nut halves.
  - Insert a stiff compression die-spring between them on a guide pin.
  - The spring forces Nut 1 and Nut 2 continuously against opposing flanks of the thread simultaneously, eliminating 100% of axial backlash even as the nut wears down over years of operation.

---

## 2. Four-Bar Linkages & Straight-Line Kinematics

Mechanical linkages allow makers to convert rotary motor power into complex curved or straight-line motions without using sliding rails or computer interpolation.

```
Grashof's Four-Bar Kinematic Law:
  Let s = shortest link, l = longest link, p & q = other two links.
  
  Condition:
    s + l <= p + q  ---> At least one link can make a complete 360° rotation!
```

---

### A. The Scotch Yoke: Pure Sinusoidal Linear Motion
Standard engine slider-crank mechanisms use an angled connecting rod, which exerts heavy side-thrust forces against cylinder walls and distorts harmonic acceleration.

```
Scotch Yoke Mechanism:
  [Motor Rotary Crank (Radius R)] ===(Roller Pin)===> [Slotted Yoke Bar]
                                                             |
                                                             v
  ====> Delivers Pure Sinusoidal Linear Motion: x(t) = R * cos(ωt)
        with ZERO connecting rod angularity or lateral side-thrust!
```
- **Repurposing Exploits**:
  - Direct coupling to high-pressure water pumps or diaphragm compressors.
  - Heavy-duty vibrating laboratory sieve tables and shaker polishers.

---

### B. Chebyshev's Lambda Walking Linkage
- Converts smooth circular rotation from a single salvaged wiper or drill motor into a foot path that mimics the flat, ground-contact walking gait of an animal.
- Four linked lambda mechanisms driven by a central camshaft create an **all-terrain walking hexapod robot** that walks over mud and rock steps without requiring computer servo control.

```
Chebyshev's Walking Foot Path:
        /-------\  (Lift & Return Phase)
       /         \
  ----+-----------+---- Ground Level
      <===========> (Long, Flat, Constant-Velocity Push Phase)
```

---

### C. The Peaucellier-Lipkin Exact Straight-Line Mechanism
Before precision linear bearings were invented, machining flat surfaces was nearly impossible because machine tools had no straight edges to copy.
- The Peaucellier linkage consists of **eight rigid bars pinned at joints with zero sliding contacts**:
  - Four equal-length bars forming a rhombus ($B-C-D-E$).
  - Two equal-length longer tie rods pinned to a fixed anchor ($A$).
  - One pivoting crank arm ($F$).
- **The Mathematical Miracle**: As Crank $F$ turns in a circle, the output pin at the opposite corner of the rhombus moves in an **exact, mathematically flawless straight line perpendicular to the base**!
- *Projects*: High-temperature 3D printer Z-axes or ultra-clean vacuum chamber probe mechanisms where lubricants and ball bearings would burn or off-gas.
