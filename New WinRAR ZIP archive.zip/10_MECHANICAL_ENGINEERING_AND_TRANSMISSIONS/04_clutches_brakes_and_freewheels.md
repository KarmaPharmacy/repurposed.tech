# ⚙️ Volume 10.4: Clutches, Electromagnetic Brakes & Overrunning Freewheels
*Hacking 12V car AC compressor clutches, sprag one-way bearings, centrifugal couplers, and band brakes.*

---

## 1. Automotive AC Compressor Clutches: 12V Instant Mechanical PTO

```
Electromagnetic Clutch Assembly Cutaway:
+-------------------------------------------------------------+
| [12V High-Flux Electromagnetic Coil (Stationary Housing)]   |
|                             |                               |
|          (Magnetic Flux jumps across 0.5mm air gap)         |
|                             |                               |
| [Belt Pulley with Double-Row Ball Bearing (Spins Freely)]   |
|                             |                               |
|          (Friction Surface Clamp: 40+ Nm Holding Torque)    |
|                             |                               |
| [Spring-Steel Armature Drive Plate (Keyed to Output Shaft)] |
+-------------------------------------------------------------+
```

### Why Makers Scavenge AC Compressor Clutches:
In modern automotive junkyards, air conditioning compressors are ubiquitous. Bolted to the front of every compressor is a **self-contained 12V electromagnetic dry friction clutch**.
- **Specifications**:
  - Operating Voltage: **12V DC (Draws 3.0A to 4.2A)**.
  - Torque Capacity: Easily transmits **30 to 50+ Nm (25 to 37 ft-lbs)** without slipping.
  - Speed Capability: Rated for continuous engine speeds up to **7,000+ RPM**.
  - Air Gap Setting: Adjust shims behind the armature plate to maintain **0.35 mm to 0.65 mm (0.014" to 0.025")**.

---

### Step-by-Step Repurposing Exploits:

#### A. Dual-Drive Mechanical Hybrid Powerhead
- Mount an electric motor and a small 4-stroke gas engine on opposite sides of a common driveshaft.
- Run the belt drive through an AC compressor clutch:
  - *Switch Open (0V)*: The electric motor spins the output shaft with zero drag from the unpowered gas engine.
  - *Switch Closed (12V)*: The electromagnetic clutch snaps closed in **15 milliseconds**, instantly locking the gas engine to the drive.
  - Allows seamless switching between silent indoor battery power and high-endurance outdoor gas power for custom tractors, boats, and go-karts.

#### B. Instant Emergency Mechanical Decoupler (Fail-Safe)
- In heavy automated machinery (cable winches, industrial mixers, log splitters), cutting electrical motor power does not stop mechanical inertia immediately—the spinning rotor keeps feeding energy for several seconds.
- Route the motor output through an AC clutch.
- Wire an emergency stop button to cut 12V power to the clutch coil. The spring-steel leaves snap the load completely free from motor inertia in **under 20 milliseconds**, preventing catastrophic mechanical jams.

---

## 2. Sprag Clutches & One-Way Needle Bearings (Mechanical Diodes)

```
Sprag Clutch vs. Conventional Bearing:
          [Outer Circular Race]
                   |
     +-------------+-------------+
     |             |             |
  (Sprags Tilt) (Sprags Jam) (Sprags Tilt)  <--- Asymmetrical dog-bone sprags
     |             |             |               tilt to permit free spin,
     +-------------+-------------+               but jam wedge-tight on reverse!
                   |
          [Inner Circular Race]
```

### Sourcing Sprag Clutches & Overrunning Freewheels:
- **Automotive Starter Motors**: The Bendix drive gear contains an internal sprag clutch that prevents the started engine from back-driving and exploding the starter motor.
- **Alternator Overrunning Decoupler (OAD) Pulleys**: Modern car alternators feature one-way overrunning sprag pulleys to decouple crankshaft torsional vibration.
- **Bicycle Freehubs & Fishing Reels**: High-precision multi-roller one-way clutches.

### Repurposing Exploits:

```
Ocean Wave & Wind Oscillatory Mechanical Rectifier:
  [Rocking Buoy / Pendulum Arm (Back & Forth Motion)]
                          |
              +-----------+-----------+
              |                       |
              v                       v
      [Sprag Clutch 1]        [Sprag Clutch 2 (Geared Reverse)]
              |                       |
              v                       v
  ====> Delivers 100% UNIDIRECTIONAL Continuous Rotation to Generator!
```

#### A. Mechanical Wave & Wind Energy Rectifier
- Ocean waves, swinging tree branches, and swaying pendulum mechanisms oscillate back and forth in two directions. Standard generators require continuous single-direction rotation to produce power efficiently.
- By mounting two opposing sprag one-way clutches linked by an idler gear, **oscillating clockwise and counter-clockwise motion is mechanically rectified into smooth, continuous single-direction rotation** driving an alternator.

#### B. Anti-Rollback Safety Hoist
- Install a sprag needle bearing on the winch drum shaft of a boat ramp hoist or elevator lift.
- The drum spins freely when winding cable upward, but **mechanically jams solid the microsecond power cuts**, preventing heavy loads from dropping even if the drive belt snaps.

---

## 3. Centrifugal Clutches & Mechanical Band Brakes

```
Centrifugal Clutch Mechanics:
  [Central Hub (Spun by Motor)] ===> [Spring-Retracted Heavy Friction Shoes]
                                                    |
                                       (RPM Exceeds 2,000 RPM)
                                                    |
                                                    v
  [Outer Steel Drum] <================ [Shoes Swing Out Under Centrifugal Force]
  *(Engages smooth, slip-free drive under high inertia loads)*
```

- **Sourcing**: Discarded chainsaws, gas weed whackers, and motorized go-karts.
- **Why It Matters**: High-inertia loads (heavy cast iron wood lathe faceplates, rock crushers, high-speed flywheel energy storage) require immense starting torque that can burn out electric motors.
- **Repurposing**: The centrifugal clutch acts as an automatic mechanical soft-starter: The electric motor spins up to full speed and torque unencumbered; as it hits operating RPM, the friction shoes expand smoothly to bring the heavy flywheel up to speed without tripping household circuit breakers.
