# ⚙️ Volume 10.1: Shaft Couplings, Hub Adapters & Machining Salvaged Shafts
*How to couple odd, splined, D-cut, and metric motor shafts to real-world mechanical loads without slipping, wobble, or shaft failure.*

---

## 1. The Scrapper's Shaft Dilemma: Mismatched Geometry

Salvaged electric motors rarely come with standard 1/2", 5/8", or 8mm keyed cylindrical output shafts. They are typically:
- Splined or helical-cut directly onto the armature shaft.
- Tapered with an internal retaining thread (e.g., alternator rotors).
- D-shafts with shallow flats (e.g., microwave turntable and stepper motors).
- Poly-V multi-ribbed pulley bosses permanently pressed onto the shaft (treadmill motors).

```
Shaft Adaptation Hierarchy:
+-------------------------------------------------------------------------+
| Shaft Type         | Best Coupling Method         | Fabrication Tactic  |
| ------------------ | ---------------------------- | ------------------- |
| **Smooth Round**   | Clamping Split-Collar Hub    | Never rely on set-  |
|                    | or Trantorque Bushing        | screws alone!       |
| **D-Shaft (Flat)** | Broached D-Bore Clamping Hub | Dual opposed screws |
| **Splined Shaft**  | Harvest Matching Female Hub  | Cut off donor mating|
|                    | or Epoxy Spline Casting      | gear & weld to hub  |
| **Tapered Shaft**  | Lathe-Turned Matching Taper  | Measure taper angle |
|                    | with Draw-Bolt Retention     | with dial indicator |
| **Pressed Pinion** | Puller Extraction OR Turn    | Anneal with torch,  |
|                    | Down Pinion into a Round Hub | turn teeth on lathe |
+-------------------------------------------------------------------------+
```

---

## 2. Shaft Couplers: Selection, Alignment & Misalignment Tolerance

```
Types of Mechanical Couplers:
  A. Rigid Sleeve / Split Hub:       B. Jaw / Spider (Lovejoy):
     [ Shaft 1 ]=====[ Shaft 2 ]        [ Hub 1 ]===(Polyurethane)===[ Hub 2 ]
     - Zero angular tolerance           - Absorbs 1°-2° angular misalignment
     - Zero parallel tolerance          - Dampens torsional shock loads
     - Maximum torque transfer          - Sacrificial elastomer insert
     
  C. Oldham Coupler:                 D. Helical Beam Coupler:
     [ Hub 1 ]--[Center Disc]--[ Hub 2] [ One-Piece Slotted Aluminum Cylinder ]
     - Absorbs parallel misalignment    - High precision, zero backlash
     - Sliding cross-disc action        - Fragile under high shock torque
```

### The Golden Rule: Set-Screws vs. Clamping Hubs
- **Why Set-Screws Fail**: A simple set-screw bearing down on a round steel shaft contacts only a microscopic point. Under alternating torque, the screw tip indents the shaft, loosens, and scores a ring around the shaft, permanently ruining concentricity.
- **The Split-Clamping Collar Solution**:
  A clamping hub has an axial slit tightened by a tangential pinch bolt. Tightening the bolt contracts the entire cylindrical bore uniformly around the shaft, utilizing **360° of static friction**.
  - Clamping collars transmit up to **10 times the torque of a set-screw** with zero shaft gouging.

---

## 3. Extracting and Machining Case-Hardened Shafts

Many high-torque motors (wipers, drills, starters) use **case-hardened carbon steel or carburized alloy shafts** (Rockwell 58–62 HRC). Attempting to drill or turn them with standard High-Speed Steel (HSS) tooling will immediately burn and dull the cutter.

```
Hardened Pinion Removal / Adaptation Protocol:
  Method 1: The Mechanical Gear Puller
    - Use a dedicated 2-jaw or 3-jaw miniature bearing puller.
    - Heat the pinion gear rapidly with a micro-butane torch (thermal expansion)
      while keeping the motor shaft cool with a wet rag.
      
  Method 2: Turning the Pinion into a Shaft Adapter
    - If the gear cannot be pulled off: Chuck the motor armature in a lathe.
    - Use a Carbide (CBN - Cubic Boron Nitride) insert tool bit.
    - Run lathe at slow RPM with continuous oil cooling.
    - Turn the hardened gear teeth down into a smooth, concentric round boss
      that fits a standard bearing or clamping coupling!
```

---

## 4. Keyways, Flats & Spline Broaching at Home

```
DIY Keyway Broaching in a Drill Press or Vise:
+-------------------------------------------------------------+
| [Bushing inserted into pulley bore with keyway slot]        |
|                             |                               |
| [Stepped High-Speed Steel Broach Blade]                     |
|                             |                               |
| [Hydraulic Bottle Jack / Heavy Drill Press Quill Pressure]  |
|                             |                               |
| ====> Pushes broach through bore, cutting clean 3/16" keyway|
+-------------------------------------------------------------+
```

1. **Filing a Precision D-Flat**:
   - Wrap the motor bearings in tape to keep metal shavings out of the magnetic air gap.
   - Clamp the motor rigidly. Use a coarse single-cut bastard mill file supported by two flat wooden filing guides clamped to the shaft.
   - File until flat width equals approximately **1/3 of the shaft diameter**.
2. **Making Spline Mating Sleeves from Donor Gear Hubs**:
   - Never attempt to manually file internal splines into a blank collar.
   - Instead, salvage the **female mating component** from the donor machine (e.g., the splined wiper crank arm or the steering column universal joint).
   - Cut off the arm using an angle grinder, leaving the splined female hub intact.
   - Chuck the hub in a lathe (or center it with a dial indicator on a drill press) and turn the outer diameter true.
   - Press-fit and weld or pin this splined hub inside your custom sprocket, pulley, or arm adapter.
