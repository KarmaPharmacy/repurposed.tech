# 🔬 Volume 5.1: Lab Salvage, Sensors & Structural Electromechanics
*Medical syringe pumps, barcode polygonal LiDAR, ATX power lab stations, and acoustic levitation.*

---

## 1. Medical & Laboratory Scrap Goldmine

```
Medical Infusion Syringe Pump Architecture:
+-------------------------------------------------------------+
| [Bipolar Micro-Stepper] ===(Ground Ball-Screw)===> [Carriage]|
|                                                      |      |
|                                       [Syringe Plunger Clamp]
|                                       [Linear Slide Bushing]|
|                                       [Optical Force Sensor]|
+-------------------------------------------------------------+
```

### A. Infusion Syringe Pumps
Medical syringe pumps are engineered to deliver micro-liters of medication per hour with life-critical accuracy.
- **Hardware**: Zero-backlash, ground micro-metric leadscrew, miniature high-step-angle hybrid stepper, precision linear rails, and optical force-limit sensors.
- **Repurposing Projects**:
  - **Automated Solder Paste & Flux Dispenser**:
    - Mount a standard 10cc or 30cc syringe filled with SMD solder paste or liquid tacky flux into the carriage.
    - Wire an Arduino with an A4988 driver connected to a foot-switch pedal.
    - Pressing the foot switch advances the leadscrew by exact microsteps (e.g., 20 microsteps), dispensing repeatable, microscopic solder paste dots on 0402 surface-mount PCB pads with zero mess or dripping.
  - **Precision Hydroponic pH & EC Micro-Dosing**:
    - Accurately meters concentrated phosphoric acid or nutrient solutions down to single drops (0.05 mL) into hydroponic reservoir tanks based on live pH sensor readings.

### B. Peristaltic Pumps (From Dialysis & Chemical Scrubbers)
- **Mechanism**: A rotor with 3 or 4 rollers compresses a flexible silicone tube. Fluid is moved via peristalsis and **never touches any mechanical parts or seals**.
- **Repurposing**:
  - **Automated Cocktail Drink Mixer ("BarBot")**: Multiple peristaltic pumps meter out spirits, syrups, and juices to the exact milliliter without contamination or sticky valve clogs.

### C. Laboratory Centrifuges
- **Hardware**: Heavy dynamically balanced rotors driven by high-speed brushless motors.
- **Repurposing**:
  - **DIY Spin Coater for Thin-Film Nanotechnology**: Mount a small vacuum chuck to the spindle. Drop liquid photoresist, conductive polymer, or graphene dispersion onto a glass slide or silicon wafer; spin at 4,000 RPM for 30 seconds to produce a uniform film just nanometers thick.

---

## 2. Optical Sensors & Ultrasonic Transducers

```
Polygonal Mirror LiDAR Architecture:
  [Laser Diode] ---> [Rotating 8-Sided Polygonal Mirror] ===> [Sweeping Beam (360°)]
                                   ^                                |
                                   |                                v
                    [15,000 RPM Brushless Motor]            [Target Object]
                                                                    |
  [High-Speed Photodiode] <=========================================+
```

### A. Barcode Scanner Polygonal Mirror Motors
- **Hardware**: An 8-sided or 12-sided optical polygonal mirror block mounted to an ultra-precise brushless DC motor running at 10,000 to 25,000 RPM with phase-locked rotational stability.
- **Repurposing**:
  - **360° Planar Optical LiDAR Scanner**: Sweep a focused time-of-flight (ToF) laser rangefinder beam across a room to generate real-time 2D spatial point clouds for autonomous robot vacuum mapping.

### B. Ultrasonic Humidifier Ceramic Piezo Transducers
- **Hardware**: High-frequency piezoelectric ceramic disks resonating at 1.7 MHz to 2.4 MHz.
- **Repurposing**:
  - **Acoustic Levitation (Standing Wave Tractor Beam)**: Arraying opposing ultrasonic transducers creates standing acoustic waves with high-pressure nodes that suspend water droplets, small beads, or insects motionless in mid-air.
  - **Aeroponic Root Fogging**: Disintegrates water and plant nutrients into an ultra-fine 5-micron dry fog that delivers maximum oxygen directly to suspended roots.

---

## 3. Power & Structural Hardware: The ATX Bench Power Supply

```
ATX 24-Pin Connector Conversion:
+-------------------------------------------------------------+
| Green Wire (Pin 16: PS_ON) ---> Connect to Black Wire (GND) |
|                                 (Turns power supply ON!)    |
|                                                             |
| Yellow Wires  ---> +12V Rail (Typically 30A to 50A!)        |
| Red Wires     ---> +5V Rail  (Typically 20A to 30A)         |
| Orange Wires  ---> +3.3V Rail (Typically 15A to 25A)        |
| Black Wires   ---> Common Ground                            |
+-------------------------------------------------------------+
```

### The Free 500W High-Current Benchtop Lab Station:
Discarded computer desktop ATX power supplies are among the most versatile resources on Earth.
1. Clip the green wire (`PS_ON`) and connect it through a toggle switch to any black wire (`GND`). Flipping this switch turns on the power supply without needing a computer motherboard.
2. Solder banana plug binding posts to:
   - **Yellow (+12V)**: Powers heavy windshield wiper motors, drill motors, and audio amplifiers.
   - **Red (+5V)**: Powers microcontrollers, logic circuits, and USB devices.
   - **Orange (+3.3V)**: Powers low-voltage ESP32, STM32, and Raspberry Pi boards.
   - **Black (GND)**: Common ground.
3. Features built-in short-circuit and over-temperature shutdown protection, making it virtually impossible to destroy on your test bench.
