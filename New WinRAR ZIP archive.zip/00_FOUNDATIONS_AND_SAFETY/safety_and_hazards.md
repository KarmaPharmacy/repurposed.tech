# ⚠️ Volume 0.1: Scrapper's Safety Protocols & Lethal Hazards Field Guide
*The non-negotiable rules for hardware dismantling, toxic mitigation, and life preservation.*

---

## 1. Electrical Hazards: The Silent Killers

### A. High-Voltage Capacitors & Stored Energy
Electronic equipment can hold lethal energy hours, days, or months after being disconnected from wall power. 

```
Stored Energy Formula:
  E = 0.5 * C * V^2
  Where:
    E = Energy in Joules
    C = Capacitance in Farads
    V = Voltage across terminals
```
*Note: A shock exceeding **10 Joules** is hazardous; **50 Joules** across the chest is frequently fatal.*

| Donor Equipment | Component | Typical Stored Voltage | Typical Capacitance | Stored Energy | Danger Level |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Microwave Oven** | High-Voltage Capacitor | 2,100V – 2,500V AC/DC | 0.9 µF – 1.1 µF | ~3.0 J (High Voltage Arc) | 🔴 Extremely High |
| **Old CRT Monitors / TVs** | Anode Tube / Flyback Cap | 15,000V – 30,000V DC | 1,000 pF – 2,000 pF | ~0.5 – 1.0 J (Reflex shock) | 🔴 High / Fall hazard |
| **Camera Strobe / Xenon Flash** | Photoflash Electrolytic | 330V DC | 120 µF – 350 µF | ~10 J – 19 J | 🔴 Severe Burn / Fibrillation |
| **Variable Frequency Drive (VFD)**| DC Bus Filter Banks | 320V – 650V DC | 1,000 µF – 4,700 µF | **100 J to 1,000+ J** | ☠️ LETHAL |
| **Desktop ATX Power Supply** | Primary Electrolytic Caps | 200V – 400V DC | 470 µF – 1,000 µF | ~20 J – 80 J | 🔴 Severe Shock / Burn |

#### Safe Discharge Procedure (The "Resistor Stick"):
- **NEVER** use a bare screwdriver to short capacitor terminals directly. The instantaneous microsecond discharge produces an explosive arc flash that can weld the screwdriver tip, vaporize metal into your eyes, and rupture the capacitor casing.
- **Fabricate a Discharge Wand**: Connect a **1 kΩ to 5 kΩ, 25-Watt to 50-Watt ceramic wirewound resistor** across two heavily insulated probes (rated for 1,000V+).
- Connect the alligator clip of one probe to the capacitor's negative or chassis ground terminal.
- Firmly press the insulated resistor probe to the positive terminal and hold for **10 full seconds**.
- Verify zero residual potential with a digital multimeter set to DC volts before touching any part of the circuit.

---

### B. Microwave Oven Transformers (MOT)
The stock high-voltage transformer from a domestic microwave oven step-ups 120V/240V mains up to **2,000V–2,400V AC at 500mA to 1,000mA (0.5 to 1 Amp)**.

> [!CAUTION]
> **Zero Tolerance**: The human threshold for "cannot let go" muscular paralysis is roughly **10 to 16 mA**. Ventricular fibrillation occurs at **50 to 100 mA**. A stock microwave transformer delivers **10 times the current required to stop a human heart instantly**.
> - **RULE**: NEVER power on a stock microwave transformer on your bench. 
> - **RULE**: The ONLY safe way to repurpose an MOT is to physically cut out and remove the secondary high-voltage winding while completely unpowered, replacing it with 2–3 turns of low-voltage heavy-gauge welding cable (turning it into a safe 3.5V high-current source for spot welding).

---

## 2. Chemical, Heavy Metal & Toxic Substance Hazards

```
+--------------------------------------------------------------------------+
| TOXIC CONTAMINANT MATRIX                                                 |
|                                                                          |
| Component                 Toxin                 Action Required          |
| ------------------------------------------------------------------------ |
| Microwave Magnetron Dome  Beryllium Oxide (BeO) NEVER grind/sand ceramic |
| Fluorescent Backlights    Mercury Vapor         Do not fracture glass    |
| Old Thermostats/Switches  Liquid Mercury        Seal in glass jar if found|
| Lead-Acid / CRT Glass     Lead / Lead Oxide     Wash hands, do not grind |
| NiCad Power Tool Packs    Cadmium               Recycle intact           |
| Lithium Pouch / Cylinders Flammable Electrolyte No puncture; sand bucket |
+--------------------------------------------------------------------------+
```

### A. Beryllium Oxide (BeO) in Microwave Magnetrons
- **Where it is found**: Inside the microwave magnetron assembly (the RF generator tube), the ceramic insulator collars (often colored off-white, light grey, or pink) frequently contain **Beryllium Oxide**.
- **The Risk**: In solid form, BeO ceramic is safe to handle. However, if you attempt to crush, cut, sand, or grind this ceramic, the resulting microscopic airborne dust causes **Berylliosis**—an incurable, chronic, and potentially fatal granulomatous lung disease.
- **Protocol**: When harvesting the large ferrite ring magnets from a microwave magnetron, **unbolt or bend the sheet metal casing only**. Do not chisel, saw, or fracture the ceramic insulator core.

### B. Mercury in CCFL Tubes & Vintage Switches
- Flatbed scanners, older LCD monitors, and photocopy machines often use Cold Cathode Fluorescent Lamps (CCFLs) for illumination.
- These long glass tubes contain small amounts of elemental mercury and phosphor coatings. If fractured, mercury vapor is released instantly. Always remove the CCFL intact, or choose newer LED-illuminated donors.

### C. Lithium-Ion Thermal Runaway & Battery Salvage
Harvesting 18650 or 21700 lithium-ion cells from discarded laptop batteries, hoverboards, and power tool packs is one of the most rewarding parts of maker life, but demands rigorous safety protocols:
1. **Never Harvest Cells Below 1.5V**: If an 18650 cell has sat discharged below 1.5V for extended periods, internal copper shunts and dendrites form. Recharging such cells can cause internal micro-shorts leading to violent thermal runaway days later.
2. **Never Cut Through Nickel Strips with Conductive Wire Cutters Across Terminals**: Touching the positive rim and negative can simultaneously causes an immediate short circuit that will weld your cutters and ignite the cell.
3. **Emergency Suppression**: Lithium battery fires cannot be extinguished with water or standard ABC dry chemical extinguishers. Keep a metal bucket of clean, dry play sand nearby to bury any cell that begins venting or overheating.

---

## 3. Stored Mechanical Energy (Springs & Implosions)

### A. Coiled Clockwork Torsional Springs
```
        /-----\
      /   ---   \
     |   / - \   |  <=== Tightly coiled spiral spring under immense
      \  \---/  /        tension inside plastic housing!
        \-----/
```
- **Where found**: Lawnmower pull-start assemblies, retractable vacuum cleaner cord winders, tape measures, roll-up window blinds, and garage door openers.
- **Hazard**: These housings enclose several feet of hardened spring steel coiled under high rotational tension. Opening the shell without releasing tension causes the spring to explode outward like a razor-sharp steel whip.
- **Mitigation**: Wear heavy leather welding gloves and a polycarbonate full-face shield. Slowly unwind the spool until all mechanical tension is relieved before unfastening central pins.

### B. Vacuum Chamber Implosion Physics
When repurposing refrigerator compressors to create DIY vacuum chambers:
- **Atmospheric Pressure**: Atmospheric pressure at sea level is **14.7 pounds per square inch (PSI)**.
- Over a modest 12-inch diameter circular chamber lid, the total atmospheric crushing force pressing down under full vacuum is:
  $$\text{Area} = \pi \times r^2 = \pi \times 6^2 \approx 113.1 \text{ sq inches}$$
  $$\text{Total Force} = 113.1 \times 14.7 \approx 1,662 \text{ pounds of force!}$$
- **Material Rules**:
  - **NEVER use flat window glass or plate glass**: Glass possesses microscopic surface flaws. Under 1,600 lbs of load, it shatters without warning, spraying thousands of glass daggers inward and outward.
  - **NEVER use cheap extruded acrylic (Plexiglas)**: Acrylic suffers from "crazing" when exposed to alcohol, solvents, or cyclic tension, and shatters brittlely under vacuum.
  - **USE Cast Polycarbonate (Lexan)**: Minimum **3/4-inch to 1-inch thickness**. Polycarbonate has exceptional impact resistance and will bow noticeably rather than shatter if overloaded.
  - **USE Heavy Stainless Steel Stockpots or Pressure Cooker Bases**: Avoid thin sheet aluminum pots that can collapse like soda cans.

---

## 4. Refrigerant & Pressurized Gas Regulations
- **Environmental & Legal Mandate**: In many jurisdictions (e.g., US EPA Section 608), venting fluorocarbon refrigerants (R-12, R-22, R-134a) to the atmosphere is a severe federal violation. 
- **Hydrocarbon Hazard (R-600a / Isobutane)**: Modern domestic refrigerators frequently utilize **R-600a (isobutane)**. It is ozone-friendly but **extremely flammable**. Cutting compressor lines with an angle grinder or torch while flammable refrigerant remains inside can trigger an explosion.
- **Protocol**: Only harvest compressors from refrigerators that have been professionally evacuated and tagged by a certified HVAC recovery technician, or score scrap units where lines are already cleanly opened.
