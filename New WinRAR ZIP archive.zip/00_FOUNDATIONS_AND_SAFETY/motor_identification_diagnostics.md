# 🔍 Volume 0.2: Motor Identification & Benchtop Diagnostics
*A systematic field guide to reverse-engineering mystery motors salvaged from unknown scrap.*

---

## 1. The Scrapper's Wire-Count Diagnostic Tree

When pulling a motor from an unlabelled housing, the wire count exiting the motor frame is your first and most reliable diagnostic indicator.

```
                          [ COUNT EXTRACTED WIRES ]
                                      |
         +----------------------------+----------------------------+
         |                            |                            |
      2 WIRES                      3 WIRES                      4 WIRES
         |                            |                            |
  [Brushed DC or AC]           [3-Phase BLDC,               [Bipolar Stepper or
  - Commutator / Brushes?       AC Cap-Run Induction,        Independent Dual Coil]
  - Permanent Magnet = DC       or Split-Phase AC]          - 2 distinct isolated
  - Field Windings = Universal                              circuits with equal Ω
         |                            |                            |
         +----------------------------+----------------------------+
         |                                                         |
      5 WIRES                                                   6 WIRES
         |                                                         |
  [Unipolar Stepper]                                        [Unipolar Stepper with
  - 1 Common Wire                                            Two Center Taps or
  - 4 Coil Leads (Equal Ω to Common)                         Split Bipolar Coils]
         |                                                         |
         +---------------------------------------------------------+
         |
      8+ WIRES
         |
  [BLDC with Hall Sensors: 3 Heavy Phases + 5 Thin Signal Wires]
  OR [8-Wire Universal Stepper: 4 Independent Coils]
```

---

## 2. In-Depth Diagnostics by Motor Category

### A. Two-Wire Motors: Brushed DC vs. Universal AC/DC vs. Shaded-Pole AC

```
          Commutator & Brush Identification:
          
             [ Carbon Brush ] ----> [ + ]
                    |
                    v
             [/// COMMUTATOR ///] === (Rotating Armature)
                    ^
                    |
             [ Carbon Brush ] ----> [ - ]
```

1. **Permanent Magnet Brushed DC (PMDC)**:
   - *Physical Clues*: Strong magnetic resistance (cogging) when spinning the shaft by hand. Two access caps for carbon brushes on opposite sides of the rear bell.
   - *Multimeter Test*: Measures low resistance (typically 0.5 Ω to 20 Ω across terminals).
   - *Back-EMF Test*: Connect your multimeter set to **DC Volts** across the two wires. Spin the shaft sharply with your fingers. The meter will read a positive or negative DC voltage spike depending on spin direction.
   - *Reversibility*: Swap positive and negative voltage leads to reverse rotation direction instantly.
   - *Found In*: Cordless power tools, automotive wipers, window regulators, treadmill motors, RC cars, computer cooling fans (note: PC fans have internal brushless driver chips—see below).

2. **AC/DC Universal Motor (Series Wound)**:
   - *Physical Clues*: Carbon brushes present, but the stator has copper wire windings (field coils) instead of permanent magnets. Virtually zero magnetic cogging when spun by hand.
   - *Multimeter Test*: Low resistance (1 Ω to 15 Ω).
   - *Operating Nature*: Operates on either AC or DC current. The armature and stator windings are connected in series.
   - *Speed Nature*: Extremely high speed (10,000 to 25,000 RPM) with screaming noise under no-load. Will run away to destruction if not loaded or controlled.
   - *Found In*: Vacuum cleaners, blenders, routers, circular saws, angle grinders, older front-load washing machines.

3. **Shaded-Pole AC Induction Motor**:
   - *Physical Clues*: Only 2 wires exiting. Solid laminated iron stator stack with single AC coil. Prominent heavy copper rings embedded into one corner of each stator pole shoe (the "shading coils"). No brushes, no magnets, completely smooth rotor spin.
   - *Multimeter Test*: 10 Ω to 150 Ω resistance.
   - *Operating Nature*: Strictly single-phase AC mains (120V or 230V). Unidirectional rotation determined permanently by the physical placement of the copper shading rings.
   - *Found In*: Bathroom exhaust fans, microwave blower fans, old phonographs, refrigerator evaporator fans.

---

### B. Three-Wire Motors: 3-Phase BLDC vs. Single-Phase AC Capacitor-Run

```
3-Wire Resistance Test Matrix:
  Test across Pin 1-2, Pin 2-3, Pin 1-3.
  
  Condition A (BLDC):
    R(1-2) == R(2-3) == R(1-3)  [All Equal Low Resistance, e.g. 1.2 Ω]
    -> 3-Phase Brushless Motor (Star or Delta)
    
  Condition B (AC Capacitor-Run):
    R(Common-Run) = Low Ω (e.g., 20 Ω)
    R(Common-Start) = Higher Ω (e.g., 45 Ω)
    R(Run-Start) = Sum of Both (e.g., 65 Ω)
    -> Single-Phase Induction Motor requiring Run Capacitor
```

1. **3-Phase Brushless DC (BLDC) / PMSM**:
   - *Resistance*: Exactly identical resistance across all three wire combinations (typically 0.1 Ω to 10 Ω depending on power rating).
   - *Back-EMF Test*: Set DMM to **AC Volts**. Spin the shaft. Any pair of wires will generate clean AC sinusoidal voltage. Shorting all three wires together produces intense, smooth magnetic braking resistance.
   - *Found In*: Drone motors, hard drive spindles, optical drive spindles, hoverboards, washing machine direct drives.

2. **Single-Phase AC Induction (Capacitor-Run / PSC)**:
   - *Resistance*: One wire is Common (Neutral). The other two are Run winding and Start winding.
   - *Wiring*: Run capacitor (typically 5 µF to 30 µF, 370V AC rated) connects between Run and Start leads. AC Live connects to Run; AC Neutral connects to Common. Reversing which side of the capacitor connects to Live reverses motor direction.
   - *Found In*: Ceiling fans, garage door openers, HVAC blower fans, washing machine drain pumps.

---

### C. Four, Five & Six-Wire Motors: Stepper Motors

```
Bipolar (4-Wire):               Unipolar (5-Wire):              Unipolar (6-Wire):
   Coil A1 o---/\/\/\---o A2         Coil 1 o---/\/\/\---+            Coil A1 o---/\/\/\---o Center A
                                                         |                           |
   Coil B1 o---/\/\/\---o B2         Coil 2 o---/\/\/\---+---o Common                o---/\/\/\---o A2
                                                         |
                                     Coil 3 o---/\/\/\---+            Coil B1 o---/\/\/\---o Center B
                                                         |                           |
                                     Coil 4 o---/\/\/\---+                           o---/\/\/\---o B2
```

1. **4-Wire Bipolar Stepper**:
   - Contains two electrically isolated coils (Coil A and Coil B).
   - *Diagnostic Test*: Use a continuity beeper. Touch probe 1 to wire 1. Find the one matching wire that beeps (Coil A). The remaining two wires will beep together (Coil B). There should be infinite resistance between Coil A and Coil B.
   - *Phase Check*: Twist the two wires of Coil A together. The motor shaft will instantly become hard to turn by hand (dynamic braking). Untwisting them frees the shaft.

2. **5-Wire Unipolar Stepper**:
   - Contains four coils sharing one common center-tap wire connected internally.
   - *Diagnostic Test*: Measure resistance between all 10 possible wire pairs.
   - *Result*: The **Common wire** is the unique wire that shows resistance $R$ to all four other wires. Any two non-common wires will show exactly $2 \times R$ between each other!

3. **6-Wire Stepper (Universal)**:
   - Contains two independent coils, each with a center-tap wire brought outside.
   - *Flexibility*: Can be used as a unipolar motor (connecting center taps to VCC) or converted into a higher-torque bipolar motor by simply **taping off and ignoring the two center-tap wires**.

---

### D. Eight-Wire Motors: BLDC with Hall Effect Sensors

When you salvage a hoverboard hub motor, e-bike motor, or high-end robotics servo, you will find 8 wires exiting the hollow axle:

```
+-----------------------------------------------------------------------+
| 8-Wire BLDC Pinout Classification:                                    |
|                                                                       |
| 3 Heavy-Gauge Wires (Power Phases):                                   |
|   - Phase U (often Yellow)                                            |
|   - Phase V (often Green)                                             |
|   - Phase W (often Blue)                                              |
|                                                                       |
| 5 Thin Signal Wires (Hall Sensors):                                   |
|   - Sensor VCC (+5V DC, often Red)                                    |
|   - Sensor Ground (GND, often Black)                                  |
|   - Hall Sensor A (Signal, often Yellow)                              |
|   - Hall Sensor B (Signal, often Green)                               |
|   - Hall Sensor C (Signal, often Blue)                                |
+-----------------------------------------------------------------------+
```

#### Benchtop Hall Sensor Verification:
1. Connect +5V DC regulated power supply to Sensor Red (+5V) and Sensor Black (GND).
2. Connect a 10 kΩ pull-up resistor from each signal wire (Yellow, Green, Blue) to +5V (Hall sensors are open-collector outputs).
3. Connect your multimeter (DC Volts) between GND and one signal wire.
4. Slowly rotate the motor shaft by hand. The voltage will toggle crisply between **0V and 5V** as the rotor magnets pass each internal Hall sensor chip.
