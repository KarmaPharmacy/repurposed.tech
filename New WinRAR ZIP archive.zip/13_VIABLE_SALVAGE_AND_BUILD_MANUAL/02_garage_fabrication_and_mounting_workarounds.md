# 🛠️ Volume 13.2: Garage Fabrication & Heavy Mounting Workarounds
*Rigid mechanical mounting, template transfer, vibration damping, and belt alignment without expensive CNC machinery.*

---

## 1. Mounting Odd-Shaped Motors Without a CNC Mill

Salvaged motors (wiper motors, alternators, treadmill motors) do not follow standardized NEMA faceplate bolt dimensions. They feature irregular, asymmetrical cast lugs, curved barrel casings, or triangular bolt circles.

```
Transferring Irregular Bolt Patterns to Steel Plate:
  Step 1: The Paper / Masking Tape Impression
    - Lay heavy cardstock or masking tape across the motor's mounting face.
    - Tap gently around the bolt holes and center pilot boss with a small ball-peen hammer.
    - The sharp edges of the holes cleanly shear the paper, leaving an exact 1:1 template!
    
  Step 2: Center Punch & Transfer
    - Glue the paper template to a 3/16" (4.5mm) or 1/4" (6mm) mild steel plate.
    - Dimple each hole center with a hardened steel center punch.
    
  Step 3: Concentric Stepped Drilling
    - Drill a tiny 1/8" (3mm) pilot hole at every punch mark.
    - Step up progressively using a Cobalt drill bit or Stepped Unibit to finished diameter.
```

---

## 2. Fabricating Slotted Tensioning Mounts

```
Filing Slotted Motor Adjustment Rails:
+-------------------------------------------------------------+
| Hole A (1/2") <====[File out central web]====> Hole B (1/2")|
|                                                             |
| ====> Creates 1.0" of continuous belt tensioning travel!    |
+-------------------------------------------------------------+
```

When building belt or chain-driven tools (belt grinders, lathes, go-karts), you **must have a method to tension the belt** as it stretches over time.
1. Mark the centerlines of your travel slot on your 3/16" mounting plate.
2. Drill Hole A at the beginning of the slot and Hole B at the end of the slot using a 3/8" or 1/2" drill bit.
3. Cut out the remaining metal web between the two holes using a drill bit or hacksaw blade, then smooth the slot flat using a coarse bastard mill file.
4. Use **Grade 8 heavy thick washers and flanged lock-nuts** so the motor cannot slip forward under heavy cutting torque.

---

## 3. Mounting Round Flangeless Motors: The Split Clamping Block

```
Split Block Motor Barrel Clamp:
+-------------------------------------------------------------+
| [Top Aluminum / Hardwood Split Block]                       |
|   |--- Semicircular cutout matching motor OD                |
|   |--- 2x Through-Bolts (Tightened to pinch barrel)         |
|                                                             |
| [Motor Barrel (PMDC / BLDC)] <--- (360° Friction Clamp)     |
|                                                             |
| [Bottom Aluminum / Hardwood Base Block]                     |
|   |--- Bolted solidly to machine frame                      |
+-------------------------------------------------------------+
```

- When a motor lacks face mounting holes (e.g., starter motors, drone outrunners, high-power DC spindle motors), **never attempt to drill holes into the motor frame**—you will pierce the stator windings or shatter internal permanent magnets.
- **The Split Clamp Solution**:
  - Bolt two thick rectangular blocks of 6061 aluminum (or high-density Baltic birch plywood) tightly together with a 1/8" shim spacer between them.
  - Bore a circular hole through the seam using a hole saw or boring head on a drill press, sized to the exact outer diameter of the motor barrel.
  - Remove the shim spacer.
  - Slip the motor inside and tighten the pinch bolts: The split block contracts uniformly around the motor casing, clamping it with thousands of pounds of static friction that cannot slip or vibrate loose.

---

## 4. Pulley & Belt Alignment: The Straight-Edge Protocol

```
Checking Pulley Coplanarity:
  [Motor Pulley]                      [Spindle Pulley]
  +============+                      +==============+
  |            |                      |              |
  |            | <==================> |              |
  +============+                      +==============+
        |                                    |
        +-----[ Machined Steel Straight-Edge ]
              *(Must touch all 4 outer pulley rims simultaneously!)*
```

### Why Visual Alignment Fails:
If two pulleys are misaligned by even **$1.5^\circ$ of angular skew or 2mm of parallel offset**:
- Timing belts will ride up against the pulley guide flanges, fraying their edges and snapping within hours.
- Poly-V multi-rib belts will squeal loudly, generate intense heat, and slip under load.

### The 4-Point Straight-Edge Test:
1. Place a precision ground steel ruler or aluminum box level across the front rim faces of both pulleys.
2. The straight-edge **must make solid contact with all four outer rim points simultaneously**:
   - Point 1 & 2 on the motor pulley outer rim.
   - Point 3 & 4 on the driven spindle pulley outer rim.
3. If there is a visible gap or rocking at any point, adjust motor shims or slide the pulley along the shaft until the ruler sits dead-flat across both wheels.

### Belt Tension Rule of Thumb:
- Apply moderate thumb pressure (approx. 10 lbs / 45 N) to the center of the belt span.
- **Correct Tension**: The belt should deflect by approximately **1/64-inch per inch of span distance** (e.g., on a 16-inch center-to-center span, the belt should deflect exactly **1/4-inch / 6mm**).
