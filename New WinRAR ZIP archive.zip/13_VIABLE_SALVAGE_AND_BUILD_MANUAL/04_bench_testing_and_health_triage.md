# 🛠️ Volume 13.4: Bench Testing & Motor Health Triage
*The 4-step go/no-go health check to verify salvaged motors before investing time and money building around them.*

---

## The Golden Rule of Salvage: Test Before You Build

Nothing is more disheartening than spending 20 hours machining custom mounting plates, welding brackets, and wiring controllers, only to flip the power switch and discover the salvaged motor has an internal ground short or burned commutator bar.

```
The 4-Step Bench Triage Workflow:
+-------------------------------------------------------------------------+
| [Step 1: Insulation Resistance to Ground] ---> Must be > 10 Megohms     |
| [Step 2: Winding Symmetry & Rotation Resistance] -> Smooth, balanced    |
| [Step 3: Commutator & Brush Visual Inspection] --> Chocolate patina     |
| [Step 4: Acoustic Bearing Spin-Down Test] -------> Zero grumble / play  |
+-------------------------------------------------------------------------+
```

---

## 1. Step 1: Insulation Resistance to Ground (The Short-Circuit Check)

```
Testing for Insulation Breakdown:
  [Multimeter set to Highest Resistance Range (20 MΩ) or Megohmmeter]
         |
         +--- Probe 1: Scratched bare metal on motor frame / casing
         |
         +--- Probe 2: Motor power lead / winding terminal
         
  Target Result: INFINITE RESISTANCE (Open Circuit "OL" or > 10 MΩ)
```

- If your meter reads **under 1.0 MΩ (or beeps on continuity)** between the winding leads and the motor chassis:
  - The magnet wire enamel insulation has burned through or degraded.
  - **Verdict**: The motor is dangerous. In a 120V treadmill motor, powering this will energize your entire lathe or grinder frame with mains AC voltage! Discard or rewire.

---

## 2. Step 2: Winding Resistance & Symmetry Testing

### For 3-Phase Brushless Motors (BLDC / Direct-Drive Stators):
- Measure resistance across all three phase pairs using your lowest DMM range:
  - $R_{1-2}$
  - $R_{2-3}$
  - $R_{1-3}$
- **All three values must match within 2% to 3%** (e.g., $1.21\,\Omega, 1.20\,\Omega, 1.22\,\Omega$).
- If one pair reads significantly lower (e.g., $0.6\,\Omega$), that phase has internal shorted turns and will overheat and shudder under load.

### For Brushed DC Motors (Treadmill, Wiper, Cordless Drill):
- Connect your multimeter across the two motor leads.
- **Slowly turn the output shaft by hand through 360°**:
  - The resistance should remain steady, fluctuating smoothly between adjacent commutator bars.
  - **The Red Flag**: If the resistance spikes to infinite or jumps by $5\times$ as you rotate, you have a **broken armature wire or a burned-out commutator bar**. The motor will develop dead spots where it refuses to start.

---

## 3. Step 3: Commutator & Brush Inspection

```
Commutator Visual Health Guide:
  HEALTHY:
    - Smooth, uniform chocolate-brown or copper patina.
    - Carbon brushes have at least 1/4" (6mm) length remaining.
    - Brush springs exert firm, positive pressure.
    
  FAILED:
    - Blackened, charred, or pitted copper bars.
    - Deep circumferential grooves worn by brushes.
    - Mica insulation protruding above the copper segments.
```

### The Deadly Emery Cloth Mistake:
- **NEVER use emery cloth or sandpaper to clean a dirty commutator.**
- Emery cloth and silicon carbide sandpaper contain conductive, ultra-hard abrasive particles. When rubbed against soft copper bars, microscopic grains become permanently embedded in the copper.
- When powered, these embedded grains act as tiny chisels that rapidly chew up the carbon brushes and cause massive arcing.
- **The Correct Method**: Clean commutators using a piece of **fine maroon Scotch-Brite pad**, or dress the commutator lightly on a lathe using a sharp carbide tool bit, then undercut the mica separators using a modified hacksaw blade.

---

## 4. Step 4: The Acoustic Bearing Spin-Down Test

```
Spin-Down Deceleration Check:
  - Grasp the shaft firmly and shake radially: Must have ZERO detectable play.
  - Give the shaft an aggressive manual spin:
  
  [Healthy Bearings]: 
    - Glides smoothly for 3 to 6 seconds before gently stopping.
    - Produces a smooth, uniform whisper.
    
  [Failed Bearings]:
    - Stops abruptly in under 1 second (dried, hardened grease).
    - Emits a dry, gravelly grumble or high-pitched squeal.
```

### Replacing Bearings from Standard Stock:
Most salvaged appliances and automotive motors utilize standard industrial deep-groove ball bearings that cost **under $2.00 to replace**:
- **608-2RS**: Found in skateboards, optical drives, and small power tools (8mm bore, 22mm OD).
- **6202-2RS**: Found in alternators and washing machines (15mm bore, 35mm OD).
- **6203-2RS**: Found in alternators and treadmill motors (17mm bore, 40mm OD).
- **6205-2RS / 6206-2RS**: Found in washing machine drum spiders (25mm / 30mm bore).
- Use a small mechanical gear puller to draw off the worn bearings. Press the new rubber-sealed (2RS) bearings on by pressing **only against the inner race** with a matching socket.
