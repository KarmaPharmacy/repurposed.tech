# ⚡ Volume 13.3: Electrical Sanity & Power Architecture
*Inrush current mathematics, battery buffering, flyback diode selection, wire gauge sizing, and star grounding.*

---

## 1. The Inrush Current Trap: Why Your Power Supply Shuts Down

A maker hooks a salvaged 12V windshield wiper motor or cordless drill motor to a commercial "12V 10-Amp" desktop switching power supply. The moment the switch is flipped, the power supply's LED blinks, the motor twitches, and the unit immediately shuts down into "hiccup protection mode."

```
Calculating Instantaneous Inrush Current:
  When a motor is stationary (0 RPM), it generates ZERO Back-EMF.
  
  Inrush Current Formula:
    I_inrush = V_supply / R_armature
    
  Example:
    Wiper Motor Armature Resistance R = 0.45 Ohms.
    At 12V DC:
    I_inrush = 12V / 0.45 Ohms = 26.6 AMPS!
```

- Although the motor only draws **3 to 4 Amps while running**, it demands **26+ Amps for the first 50 milliseconds** to overcome physical rotor inertia.
- Switching power supplies detect any draw exceeding their 10A current-limit trip point as a dead short circuit and shut down instantly.

---

### The Unwritten Field Fix: The Battery Buffer Topology

```
Battery-Buffered High-Current Power Station:
+-------------------------------------------------------------+
| [12V 10A Switching Power Supply / Wall Charger]             |
|                             |                               |
|          (Supplies 13.8V Float Trickle Charge)              |
|                             |                               |
|                             v                               |
| +=========================================================+ |
| | [Small 12V 7Ah SLA Battery OR 4S LiFePO4 Pack]          | |
| +=========================================================+ |
|                             |                               |
|          (Absorbs 30A - 60A Instantaneous Inrush Spikes!)   |
|                             |                               |
|                             v                               |
| [BTS7960 Motor Driver] ===> [Heavy Salvaged 12V DC Motor]   |
+-------------------------------------------------------------+
```

1. Wire a small, inexpensive 12V 7Ah Sealed Lead-Acid (SLA) alarm battery or a 4S LiFePO4 battery pack in **parallel** across your 12V power supply's output terminals.
2. The power supply maintains a constant 13.8V float charge on the battery.
3. When the motor starts or hits a momentary stall load, the chemical battery discharges **30 to 50 Amps instantly** without breaking a sweat, while the power supply recharges the battery between motor cycles.
4. Your power supply will never trip again.

---

## 2. Low-Voltage Wire Gauge Sizing (Voltage Drop Physics)

At 120V AC mains, a 2.0 Volt drop over a thin wire is negligible (1.6% loss).
At **12V DC**, a 2.0 Volt drop drops operating voltage to 10.0V—a catastrophic **16.7% loss of voltage and a 31% loss of motor power** ($P = V^2 / R$).

```
12V DC Wire Sizing Matrix (Target: Less than 3% Voltage Drop over 10 ft):
+-------------------------------------------------------------------------+
| Continuous Current  | Minimum Recommended Wire Gauge  | Typical Application|
| ------------------- | ------------------------------- | ------------------ |
| **0 to 5 Amps**     | 18 AWG                          | Steppers, sensors  |
| **5 to 15 Amps**    | 14 AWG                          | Window regulators  |
| **15 to 30 Amps**   | 10 AWG (Silicone high-strand)   | Wiper motors, drills|
| **30 to 60 Amps**   | 6 AWG or 4 AWG                  | Hoverboard hubs    |
| **60 to 120 Amps**  | 2 AWG or 0 AWG (Welding cable)  | Starter, EPS column|
+-------------------------------------------------------------------------+
```

---

## 3. Flyback Clamping Diodes: Saving Your MOSFETs

Electric motor windings are massive electrical inductors.
When your microcontroller turns off a MOSFET during PWM speed control, the collapsing magnetic field in the motor windings generates an instantaneous reverse voltage spike:
$$V_{\text{spike}} = -L \frac{di}{dt}$$
- This inductive kickback easily reaches **150V to 400V in fractions of a microsecond**, exceeding the breakdown voltage of your driver's MOSFETs and blowing them instantly.

```
Flyback Diode Selection Trap:
  [1N4001 / 1N4007 Standard Diodes]:
    - Reverse Recovery Time: t_rr > 2,000 nanoseconds.
    - FATAL FLAW: At 20 kHz PWM, the diode is too slow to catch the spike!
    
  [Schottky Barrier Diodes (MBR20100CT / SR5100)]:
    - Reverse Recovery Time: t_rr < 30 nanoseconds.
    - Catches ultra-fast inductive transients instantly and runs cool.
```

- **The Rule**: Always wire a high-speed **Schottky diode** (or RC snubber network) directly across the motor's power terminals (Cathode to positive, Anode to negative) when designing custom discrete MOSFET switches.

---

## 4. Star Grounding & Logic Isolation

```
Ground Bounce Reset Phenomenon:
  [Motor High-Current Ground (20A Draw)] ---> (Thin Common Wire) ---> [Arduino GND]
                                                     |
                                        (Generates 0.8V Ground Bounce!)
                                                     |
                         ====> ARDUINO CRASHES & FREEZES REPEATEDLY!
```

### The Star Ground Rule:
High-current motor return currents must never flow through the same physical wire or copper trace as delicate 5V/3.3V microcontroller logic signals.
- **The Protocol**: Designate a single **Solid Copper Star Ground Stud** directly at the negative terminal of your power supply or battery.
- Run dedicated, isolated heavy-gauge ground wires from the motor driver directly back to the star stud.
- Run a separate, dedicated ground wire from the microcontroller to the star stud.
- Noise and ground bounce from motor brush arcing can no longer interfere with microcontroller logic.
